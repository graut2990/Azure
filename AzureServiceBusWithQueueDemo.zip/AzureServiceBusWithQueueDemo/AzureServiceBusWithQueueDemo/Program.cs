﻿using System;
using Microsoft.Azure.ServiceBus;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AzureServiceBusWithQueueDemo
{
    
    class Program
    {
        static string serviceBusConnString = "Endpoint=sb://trialservicebusss.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=70JDjrWoYUPsJ6bCj1qoluypw3zXN0qInSYZrsAOY3I=";
        static string queueName = "testqueue";
        
        static QueueClient queueClient;

        private Program()
        {
            queueClient = new QueueClient(serviceBusConnString, queueName);
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.SendMessage().Wait();
        }

        private  async Task SendMessage()
        {
            try
            {
                string messageBody = string.Empty;
                messageBody = "Message From application";
                Console.WriteLine("Hello World!");

                Message message;

                for (int i = 0; i <= 5; i++)
                {
                    message =  new Message(Encoding.UTF8.GetBytes(messageBody + i.ToString()));

                    //In Session Enabled case add the session id to message
                   // message.SessionId = Guid.NewGuid().ToString();

                   await queueClient.SendAsync(message);
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await queueClient.CloseAsync();
                Console.ReadKey();
            }
        }

        private void ReadMessage()
        {
            MessageHandlerOptions messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                // Indicates whether the message pump should automatically complete the messages after returning from user callback.
                // False below indicates the complete operation is handled by the user callback as in ProcessMessagesAsync().

                MaxConcurrentCalls = 1,
                // Indicates whether the message pump should automatically complete the messages after returning from user callback.
                // False below indicates the complete operation is handled by the user callback as in ProcessMessagesAsync().

                AutoComplete = false
            };

            queueClient.RegisterMessageHandler(ReceiveMessagesAsync, messageHandlerOptions);
        }

        private async Task ReceiveMessagesAsync(Message message, CancellationToken token)
        {
            
            Console.WriteLine(Encoding.UTF8.GetString(message.Body));

           await queueClient.CompleteAsync(message.SystemProperties.LockToken);
        }

        private Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine(exceptionReceivedEventArgs.Exception.Message);
            return Task.CompletedTask;
        }

        //Session Enabled Section
        private void ReadSessionEnabledMessage()
        {

            SessionHandlerOptions sessionHandlerOptions = new SessionHandlerOptions(ExceptionReceivedHandler)
            {
                MaxConcurrentSessions = 100,
                AutoComplete = true
            };

            queueClient.RegisterSessionHandler(ProcessMessagesInSessionAsync, sessionHandlerOptions);
        }

        private static async Task ProcessMessagesInSessionAsync(IMessageSession messageSession, Message message, CancellationToken token)
        {
            Console.WriteLine($"Received message: SequenceNumber:{message.SystemProperties.SequenceNumber} Body:{Encoding.UTF8.GetString(message.Body)}");

            await Task.CompletedTask;

            //// We don't use the CompleteAsync() method.

            //// await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);

        }
    } 
}
