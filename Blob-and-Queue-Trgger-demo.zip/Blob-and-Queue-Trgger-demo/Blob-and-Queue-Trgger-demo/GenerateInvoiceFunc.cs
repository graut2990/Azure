using System;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;

namespace BlobandQueueTrggerdemo
{
    public static class GenerateInvoiceFunc
    {
        [FunctionName("GenerateInvoiceFunc")]
        public static void Run(
           [QueueTrigger("invoice-generation-request", Connection = "AzureWebJobsStorage")]InvoiceGenerationRequest request,
           [Queue("invoice-print-request")] out InvoicePrintRequest printRequest,
           [Queue("invoice-notification-request")] out string notificationRequest, TraceWriter log)
        {
            log.Info($"C# Queue trigger function processed: {request.CustomerCode} {request.Year} {request.Month}");
            InvoicePrintRequest obj = new InvoicePrintRequest();
            Invoice invoice = new Invoice();
            invoice.Customer = request.CustomerCode;
            invoice.Description = request.CustomerCode + "Dscription";
            invoice.TotalCost = 10000;
            invoice.Id = "101";
            invoice.InvoiceNumber = "Inv101";
            obj.InvoiceToPrint = invoice;
            printRequest = obj;
            notificationRequest = request.CustomerCode + "-" + request.Year + "-" + request.Month;
        }
        public class InvoiceGenerationRequest
        {
            public string CustomerCode { get; set; }
            public int Year { get; set; }
            public int Month { get; set; }

            public static InvoiceGenerationRequest ForActiveList(ActiveList activeList)
            {
                return new InvoiceGenerationRequest
                {
                    CustomerCode = activeList.CustomerCode,
                    Year = activeList.Year,
                    Month = activeList.Month
                };
            }
        }
        public class ActiveList
        {
            public string CustomerCode { get; set; }
            public int Year { get; set; }
            public int Month { get; set; }
            public string[] DataLines { get; set; }
        }
        public class Invoice
        {
            [JsonProperty("id")]
            public string Id { get; set; }
            public string Customer { get; set; }
            public string InvoiceNumber { get; set; }
            public string Description { get; set; }
            public List<InvoiceLine> Lines { get; set; }
            public decimal TotalCost { get; set; }




        }

        public class InvoiceLine
        {
            public string ItemName { get; set; }
            public decimal Cost { get; set; }
        }
        public class InvoicePrintRequest
        {
            public Invoice InvoiceToPrint { get; set; }
        }

        public class InvoiceNotificationRequest
        {
            public Invoice InvoiceForNotification { get; set; }
        }
    }
}
