using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;

namespace BlobandQueueTrggerdemo
{
    public static class Function1
    {
        //[FunctionName("Function1")]
        //public static void Run([BlobTrigger("active-lists/{name}", Connection = "AzureWebJobsStorage")]Stream myBlob, string name, TraceWriter log)
        //{
        //    log.Info($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes");
        //}

        [FunctionName("GenerateBillingItemsFunc")]
        public static void Run(
         [BlobTrigger("active-lists/{name}", Connection = "AzureWebJobsStorage")] Stream myBlob, string name,
         [Queue("invoice-generation-request")] out InvoiceGenerationRequest queueRequest, TraceWriter log)
        {
            //log.LogInformation($"C# Blob Trigger function Processed blob: {name} Bytes");
            log.Info($"C# Blob Trigger function Processed blob: {name} Bytes");
            var activeList = ActiveListParser.Parse(name, myBlob);
            queueRequest = InvoiceGenerationRequest.ForActiveList(activeList);
        }

        public class InvoiceGenerationRequest
        {
            public string CustomerCode { get; set; }
            public int Year { get; set; }
            public int Month { get; set; }

            public static InvoiceGenerationRequest ForActiveList(ActiveList activeList)
            {
                return new InvoiceGenerationRequest
                {
                    CustomerCode = activeList.CustomerCode,
                    Year = activeList.Year,
                    Month = activeList.Month
                };
            }
        }
        public static class ActiveListParser
        {
            public static ActiveList Parse(string name, Stream myBlob)
            {
                using (StreamReader sr = new StreamReader(myBlob))
                {
                    var dataLines = sr.ReadToEnd();
                    var parts = name.Split(new char[] { '_' });
                    return new ActiveList
                    {
                        CustomerCode = parts[0],
                        Year = int.Parse(parts[1]),
                        Month = int.Parse(parts[2]),
                        DataLines = dataLines.Split(Environment.NewLine.ToCharArray())
                    };
                }
            }
        }

        public class ActiveList
        {
            public string CustomerCode { get; set; }
            public int Year { get; set; }
            public int Month { get; set; }
            public string[] DataLines { get; set; }
        }

        public class Invoice
        {
            [JsonProperty("id")]
            public string Id { get; set; }
            public string Customer { get; set; }
            public string InvoiceNumber { get; set; }
            public string Description { get; set; }
            public List<InvoiceLine> Lines { get; set; }
            public decimal TotalCost { get; set; }

            public static Invoice Create(string customerCode, int year, int month)
            {
                return new Invoice
                {
                    Id = $"{customerCode}{month}{year}",
                    Customer = customerCode,
                    InvoiceNumber = $"{customerCode}/{month}/{year}",
                    Description = $"Invoice for insurance policies for {month}/{year}",
                    Lines = new List<InvoiceLine>(),
                    TotalCost = 0M
                };
            }

            //public void BillItems(List<BillingItem> itemsToBill)
            //{
            //    var groups = itemsToBill
            //            .GroupBy(bi => bi.ProductCode);

            //    foreach (var itemGroup in groups)
            //    {
            //        Lines.Add(new InvoiceLine
            //        {
            //            ItemName = $"Policy {itemGroup.Key}",
            //            Cost = itemGroup.Sum(i => Convert.ToDecimal(i.Amount))
            //        });
            //    }

            //    TotalCost = Lines.Sum(l => l.Cost);
            //}
        }

        public class InvoiceLine
        {
            public string ItemName { get; set; }
            public decimal Cost { get; set; }
        }
        public class InvoicePrintRequest
        {
            public Invoice InvoiceToPrint { get; set; }
        }

        public class InvoiceNotificationRequest
        {
            public Invoice InvoiceForNotification { get; set; }
        }
    }
}
