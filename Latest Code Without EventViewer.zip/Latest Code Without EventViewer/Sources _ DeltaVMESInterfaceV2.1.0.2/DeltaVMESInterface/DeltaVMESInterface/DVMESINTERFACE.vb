Public Class DeltaVMESInterface
    
    Protected Overrides Sub OnStart(ByVal args() As String)
        '#If (DEBUG) Then
        '        Debugger.Launch()
        '#End If

        'Set thread priority
        thCampaign.Priority = Threading.ThreadPriority.BelowNormal
        thWatchDog.Priority = Threading.ThreadPriority.BelowNormal

        '--------------------------------------------------
        'Setting the global boolean variable to false
        'to start the while loop of thread
        bterminate = False
        '--------------------------------------------------

        'Get version number of the application to log it in Event viewer
        Dim strVersion As String
        strVersion = My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & "." & My.Application.Info.Version.Build
        EventViewerLog("DeltaVMESInterface Service " & strVersion & " Starting...", "Message")

        'Read TagConfiguration file
        bReadResult = ReadTagConfigurationFile()

        'Logg in Event viewer only if Debug is set to 1 in cfg file
        If (bDebug = True) Then
            EventViewerLog("Read Tag Conifguration Complete", "Message")
        End If


        If (bReadResult = False) Then
            EventViewerLog("ReadTagConfigurationFile: Read Tag Configuration Failed.", "Error")
            Exit Sub
        End If

        If (bDebug = True) Then
            EventViewerLog("CreateTagList Started", "Message")
        End If

        'Call Create Tag List to create respective tags for each unit read from the config file
        bCreateTagList = CreateTagList()

        If (bDebug = True) Then
            EventViewerLog("CreateTagList complete", "Message")
        End If

        If (bCreateTagList = False) Then
            EventViewerLog("CreateTagList: Create Tag List Failed.", "Error")
            Exit Sub
        End If

        If (bDebug = True) Then
            EventViewerLog("thWatchDog Starting", "Message")
        End If

        'Start Watch Dog thread 
        thWatchDog.Start()
        Threading.Thread.Sleep(1000)
        If (bDebug = True) Then
            EventViewerLog("thCampaign Starting", "Message")
        End If

        'Start Campaign thread 
        thCampaign.Start()

        '#End If

    End Sub

    Protected Overrides Sub OnStop()
        ' Add code here to perform any tear-down necessary to stop your service.
        '--------------------------------------------------
        'Setting the global boolean variable to true to
        'terminate the while loop of the threads
        bterminate = True
        '--------------------------------------------------
        If Not (thCampaign Is Nothing) Then

            'While thCampaign.ThreadState <> Threading.ThreadState.Stopped

            'End While
        End If
        If Not (thWatchDog Is Nothing) Then
            'While thWatchDog.ThreadState <> Threading.ThreadState.Stopped

            'End While
        End If
    End Sub



End Class
