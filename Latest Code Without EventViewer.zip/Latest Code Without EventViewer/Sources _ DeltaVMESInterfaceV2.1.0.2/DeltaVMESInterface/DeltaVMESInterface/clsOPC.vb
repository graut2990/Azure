Imports OPCDotNetAutomation

Public Class clsOPC
    Public Const g_OPCServer As String = "OPC.DeltaV.1" 'OPC Server Name
    '================================================================================
    'Description       :Function Start OPC (Connect opc,Addd Group to server,Add items to Group)
    'Input Parameters  :OPC Item array,Tag array
    'Output Parameters :True if Folders Created sucessfully,False if failed to create
    '================================================================================
    Public Function Start_OPC(ByRef oOPCServer As OPCDotNetAutomation.OPCServer, ByRef oOPCControlGroup As OPCDotNetAutomation.OPCGroup, ByRef oOPCItem() As OPCDotNetAutomation.OPCItem, ByVal sTag() As String, ByVal strOPCGrpName As String) As Boolean

        Try

            Dim iTag As Short


            Start_OPC = False
            '---------------------------------------------------------
            ' Find and connect to the OPC Server
            '---------------------------------------------------------
            Try

                If (oOPCServer Is Nothing) Then

                    oOPCServer = New OPCDotNetAutomation.OPCServer
                    oOPCServer.Connect(g_OPCServer, strNodeName)

                End If

            Catch ex As Exception
                oOPCServer = Nothing
                Start_OPC = False
                EventViewerLog("Invalid Node Name in cfg file", "Error")

                Exit Function

            End Try
            Threading.Thread.Sleep(1000)
            '---------------------------------------------------------
            ' Create a "Control" group 
            '---------------------------------------------------------

            Try


                If (oOPCControlGroup Is Nothing) Then
                    Try
                        oOPCControlGroup = oOPCServer.OPCGroups.Add(strOPCGrpName)
                        oOPCControlGroup.UpdateRate = 1000
                        oOPCControlGroup.IsActive = True

                    Catch ex As Exception
                        EventViewerLog("Start OPC: Creating OPC Group " & strOPCGrpName, "Error")
                    End Try
                End If

            Catch ex As Exception
                Start_OPC = False

                EventViewerLog("Invalid Node Name in cfg file", "Error")
            End Try
            '---------------------------------------------------------
            'Add item to group
            '---------------------------------------------------------
            ReDim oOPCItem(UBound(sTag))
            Try

                For iTag = 0 To UBound(sTag)
                    If (sTag(iTag) <> Nothing) Or (sTag(iTag) <> "") Then
                        Try

                            oOPCItem(iTag) = oOPCControlGroup.OPCItems.AddItem(Trim(sTag(iTag)), oOPCControlGroup.ClientHandle)
                            Threading.Thread.Sleep(20)

                        Catch ex As Exception
                            Start_OPC = False
                            EventViewerLog("Start OPC: " & ex.Message, "Error")
                        End Try
                    End If

                Next iTag

                Start_OPC = True
                Exit Function
            Catch ex As Exception
                EventViewerLog("Start OPC: " & ex.Message, "Error")

            End Try

        Catch ex As Exception
            Exit Try
            EventViewerLog(strOPCGrpName & " : " & ex.Message, "Error")
            Start_OPC = False
        Finally
        End Try
    End Function

End Class
