Imports System.IO
Imports Microsoft.Win32
Imports System.Diagnostics
Imports OPCDotNetAutomation
Module modDVMES
    Structure structopc
        Dim strBatchId As String
        Dim strRecipe As String
        Dim strFormula As String
        Dim strEquipmentTrain As String
        Dim strStartCommand As String
        Dim strStatus As String
        Dim strComplete As String
    End Structure
    Public bDebug As Boolean = False
    Public strUserName As String
    Public strPassword As String
    Public strNodeName As String
    'Upgrade V11
    Public strBExecName As String
    Public bReadResult As Boolean
    Public bFrsopcdv As Boolean
    Public bCampMgr As Boolean
    Public bCreateTagList As Boolean
    Public strArrWatchDog() As String
    Public strArrCamp() As String
    Public strArrUnits() As String
    Public struOPC() As structopc
    Public strArrCampUnits() As String
    Public bOPCItemWatchDogResult As Boolean = False
    Public bOPCItemCampResult As Boolean = False
    Public oOPCCampItems() As OPCDotNetAutomation.OPCItem
    Public oOPCWatchDogItems() As OPCDotNetAutomation.OPCItem
    Public strArrPara() As String
    Public strPara As String
    Public oOPCCampResult As Object
    Public oOPCWatchDogResult As Object
    Public bDeltaVStatus As Boolean = False
    Public bDVPrev As Boolean = False
    Public bGIDOnline As Boolean = False

    Public thCampaign As New Threading.Thread(AddressOf CampaignThread)
    Public thWatchDog As New Threading.Thread(AddressOf WatchDogThread)

    Public bterminate As Boolean = False
    Public iStartCampCnt As Integer = 0
    Public iStartWatchCnt As Integer = 0
    Public oOPCCampControlGroup As OPCDotNetAutomation.OPCGroup
    Public oOPCWatchDogControlGroup As OPCDotNetAutomation.OPCGroup
    '09/08/2012
    Public oOPCServerCamp As OPCDotNetAutomation.OPCServer
    Public oOPCServerWD As OPCDotNetAutomation.OPCServer
    '***
    Public strBaseClas As String
    Public strBaseClsDesc As String
    Public bRecipeWithoutEqTrain As Boolean = False
    'Public bDebug As Boolean = True
    Public strMessageCampCreated As String = ""
    '09/08/2012
    Public iOpcReadError As Integer


    Public Function CheckFRSOPCDV() As Boolean
        '-------------------------------------------------------------------
        'Description: This function checks if FRSOPCDV.exe is running or not
        'Output: Returns True if running
        '        Returns False if not
        '-------------------------------------------------------------------
        Try

            Dim iProc As System.Diagnostics.Process()
            Dim i As Integer
            Try
                '----------------------------------------
                'Get all Processes running
                '----------------------------------------
                iProc = Process.GetProcesses()
                CheckFRSOPCDV = False
                '----------------------------------------
                'Check if FRSOPCDV.exe is running or not
                'FRSOPCDV.exe is used for OPC Read/Write.
                '----------------------------------------
                For i = 0 To iProc.Length() - 1
                    If UCase(iProc(i).ProcessName) = UCase("FRSOPCDV") Then
                        CheckFRSOPCDV = True
                    End If
                Next i
            Catch ex As Exception
                CheckFRSOPCDV = False
            End Try

        Catch ex As Exception

        Finally

        End Try
    End Function
    Public Function CheckCampMagr() As Boolean
        '-------------------------------------------------------------------
        'Description: This function checks if CAMPAIGNMGR.exe is running or not
        'Output: Returns True if running
        '        Returns False if not
        '-------------------------------------------------------------------
        Try

            Dim iProc As System.Diagnostics.Process()
            Dim i As Integer
            Try
                '----------------------------------------
                'Get all Processes running
                '----------------------------------------
                iProc = Process.GetProcesses()
                CheckCampMagr = False
                '----------------------------------------
                'Check if CAMPAIGNMGR.exe is running or not
                'CAMPAIGNMGR.exe is used to create campaign.
                '----------------------------------------
                For i = 0 To iProc.Length() - 1
                    If UCase(iProc(i).ProcessName) = UCase("dvbcampaignmgr") Then
                        CheckCampMagr = True
                        Exit For
                    End If
                Next i
            Catch ex As Exception
                CheckCampMagr = False
            End Try

        Catch ex As Exception

        Finally

        End Try
    End Function
    Public Function ReadTagConfigurationFile() As Boolean
        '-------------------------------------------------------------------
        'Description: This function reads the Tag configuration file 
        '             Adds items in respective array (CreateCampaign/WatchDog)   
        'Output: Returns True if file read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try

            If File.Exists(System.Windows.Forms.Application.StartupPath & "\DeltaVMESInterface.cfg") = True Then
                Dim frConfig As New StreamReader(System.Windows.Forms.Application.StartupPath & "\DeltaVMESInterface.cfg", False)
                Dim strWatchDogConfig As String = ""
                Dim strTextLine As String
                Dim strCampConfig As String = ""
                Dim strUnits As String = ""
                Dim strDebug As String = ""
                While frConfig.EndOfStream = False
                    strTextLine = frConfig.ReadLine()
                    If (strTextLine.Contains("NODE NAME:") = True) Then
                        strNodeName = strTextLine.Split(":").GetValue(1)
                        If (strNodeName = "") Then
                            EventViewerLog("Invalid Node Name in cfg file", "Error")
                            Exit Function
                        End If
                        'Upgrade V11
                    ElseIf (strTextLine.Contains("BEXEC NAME:") = True) Then
                        strBExecName = strTextLine.Split(":").GetValue(1)
                        If (strBExecName = "") Then
                            EventViewerLog("Invalid Batch Exec Name in cfg file", "Error")
                            Exit Function
                        End If
                    ElseIf (strTextLine.Contains("DEBUG") = True) Then
                        strDebug = strTextLine.Split(":").GetValue(1)
                        If (strDebug = "1") Then
                            bDebug = True
                        Else
                            bDebug = False
                        End If
                    ElseIf (strTextLine.Contains("*WATCH DOG PARAMETERS*") = True) Then
                        strTextLine = frConfig.ReadLine()
                        While strTextLine.Contains(";*") = False
                            If (strTextLine.Contains(":") = True) Then
                                strWatchDogConfig = strWatchDogConfig & strTextLine.Split(":").GetValue(1) & ","
                            End If
                            strTextLine = frConfig.ReadLine()
                        End While
                    ElseIf (strTextLine.Contains("*CREATE CAMPAIGN PARAMETERS*") = True) Then
                        strTextLine = frConfig.ReadLine()
                        While strTextLine.Contains(";*") = False
                            If (strTextLine.Contains(":") = True) Then
                                strPara = strPara & strTextLine.Split(":").GetValue(0) & ","
                                strCampConfig = strCampConfig & strTextLine.Split(":").GetValue(1) & ","
                                strTextLine = frConfig.ReadLine()
                            End If
                        End While
                    ElseIf (strTextLine.Contains("*UNITS*") = True) Then
                        strTextLine = frConfig.ReadLine()
                        While strTextLine.Contains(";*") = False
                            strUnits = strUnits & strTextLine & ","
                            strTextLine = frConfig.ReadLine()
                        End While
                    End If
                End While

                frConfig.Close()

                If (strWatchDogConfig <> "") Then
                    If (strWatchDogConfig.Contains(",") = True) Then
                        strArrWatchDog = strWatchDogConfig.Split(",")

                    End If
                End If
                If (strCampConfig <> "") Then
                    If (strCampConfig.Contains(",") = True) Then
                        strArrCamp = strCampConfig.Split(",")

                    End If
                End If
                If (strPara <> "") Then
                    If (strPara.Contains(",") = True) Then
                        strArrPara = strPara.Split(",")
                    End If

                End If
                If (strUnits <> "") Then
                    If (strUnits.Contains(",") = True) Then
                        strArrUnits = strUnits.Split(",")
                    End If
                End If
                ReadTagConfigurationFile = True
            Else
                EventViewerLog("Invalid cfg file", "Error")
                ReadTagConfigurationFile = True
            End If

        Catch ex As Exception
            ReadTagConfigurationFile = False
        Finally

        End Try
    End Function

    Public Function CreateTagList() As Boolean
        '-------------------------------------------------------------------
        'Description: This function creates the tag list for Create Campaign 
        '             and watch dog
        'Output:Returns True if tag craeted successfully
        '       Returns False if not
        '-------------------------------------------------------------------
        Try
            Dim iCampCnt As Integer
            Dim iUnitCnt As Integer
            Dim iItemCnt As Integer = 0

            ReDim strArrCampUnits(UBound(strArrUnits) * UBound(strArrCamp) - 1)
            For iUnitCnt = 0 To UBound(strArrUnits) - 1
                For iCampCnt = 0 To UBound(strArrCamp) - 1
                    strArrCampUnits(iItemCnt) = strArrUnits(iUnitCnt) & "/" & strArrCamp(iCampCnt)
                    iItemCnt = iItemCnt + 1
                Next
            Next
            CreateTagList = True
        Catch ex As Exception
            CreateTagList = False
        Finally
        End Try
    End Function

    Public Sub CampaignThread()
        '-------------------------------------------------------------------
        'Description: This function will be a thread called every 30 seconds 
        'Output:Returns True if thread executed successfully
        '       Returns False if not
        '-------------------------------------------------------------------
        Dim OldTime As DateTime
        Dim cOPCCampa As New clsOPC
        Try
            'Check if FRSOPCDV.exe is running
CheckFrsop: If (bFrsopcdv = False) Then
                Threading.Thread.Sleep(60000)
                GoTo CheckFrsop
            End If

            'Check if dvbcampaignmgr.exe 'Campaign manager service' is running or not
            'If Campaign Manager Service is not running log it every 1 minute in Event Viewer
CampMgr:    bCampMgr = CheckCampMagr()

            If (bCampMgr = False) Then
                EventViewerLog("DeltaVMESInterface Waiting for DeltaV Campaign Manager Service to start...", "Warning")
                Threading.Thread.Sleep(60000)
                GoTo CampMgr
            End If
            If (bDebug = True) Then
                EventViewerLog("CheckCampMagr Completed", "Message")
            End If
            Try
                If (iStartCampCnt = 0) Then
                    'Connect to OPC Server if not connected and create group
                    bOPCItemCampResult = cOPCCampa.Start_OPC(oOPCServerCamp, oOPCCampControlGroup, oOPCCampItems, strArrCampUnits, "OPCCampaign")

                    iStartCampCnt = 1

                End If
            Catch ex As Exception
                EventViewerLog("Start OPC: Campaign Thread" & ex.Message, "Error")
                Exit Sub
            End Try
            OldTime = DateTime.Now()
            iOpcReadError = 0
            While bterminate = False And iStartCampCnt = 1

                'Check time interval
                If DateDiff(DateInterval.Second, OldTime, DateTime.Now()) < 30 Then
                    GoTo CheckTime
                End If
                If (bDebug = True) Then
                    EventViewerLog("Campaign Thread: Executing ", "Message")
                End If
                Dim bReadVal As Boolean = False

                'If OPC read error disconnect and reconnect to OPC server 09/08/12
                If (iOpcReadError >= 10) Then
                    If (bDebug = True) Then
                        EventViewerLog("Restarting OPC connection: Campaign Thread", "Message")
                    End If
                    oOPCServerCamp.Disconnect()
                    'reinit error counter
                    iOpcReadError = 0
                    Try
                        'Check if FRSOPCDV.exe is running
CheckFrsop2:            If (bFrsopcdv = False) Then
                            Threading.Thread.Sleep(60000)
                            GoTo CheckFrsop2
                        End If
                        oOPCCampControlGroup = Nothing
                        oOPCServerCamp = Nothing
                        ReDim oOPCCampItems(0)
                        'Connect to OPC Server and create group
                        bOPCItemCampResult = cOPCCampa.Start_OPC(oOPCServerCamp, oOPCCampControlGroup, oOPCCampItems, strArrCampUnits, "OPCCampaign")
                    Catch ex As Exception
                        EventViewerLog("Restart OPC: Campaign Thread" & ex.Message, "Error")
                        Exit Sub
                    End Try
                End If


                'Read OPC Tag values i.e UP001_Value.cv,UP002_Value.cv etc...
                bReadVal = ReadOPCValues()

                Dim bCheckStartCommand As Boolean = False
                Dim iStructCnt As Integer

                For iStructCnt = 0 To UBound(struOPC)
                    If (bDebug = True) Then
                        EventViewerLog("Campaign Thread: Checking for start command ", "Message")
                    End If
                    bCheckStartCommand = CheckForStartCommand(iStructCnt)
                    If (bDebug = True) Then
                        EventViewerLog("Campaign Thread: Start command status " & bCheckStartCommand, "Message")
                    End If

                    'If bCheckStartCommand = True And (UCase(struOPC(iStructCnt).strComplete) = "FALSE" Or struOPC(iStructCnt).strComplete = "0") Then
                    If bCheckStartCommand = True Then
                        bCampMgr = CheckCampMagr()
                        If (bCampMgr = False) Then
                            EventViewerLog("DeltaVMESInterface Waiting for DeltaV Campaign Manager Service to start...", "Warning")
                            UpdateStatus(iStructCnt, "Campaign Manager is offline")
                        Else
                            Dim bStatus As Boolean = False
                            If (bDebug = True) Then
                                EventViewerLog("Campaign Thread: Validating Inputs ", "Message")
                            End If
                            bStatus = ValidateAndCreateCampaign(iStructCnt)
                            If (bStatus = True) Then
                                EventViewerLog(strMessageCampCreated, "Message")
                            End If
                        End If
                        bCheckStartCommand = False
                    End If
                Next

                OldTime = DateTime.Now()
CheckTime:      Threading.Thread.Sleep(10000)
            End While

        Catch ex As Exception
            EventViewerLog(ex.Message, "Error")
        Finally
            '21/08/2012
            oOPCServerCamp.Disconnect()

        End Try
    End Sub


    Public Function ReadOPCValues() As Boolean
        '-------------------------------------------------------------------
        'Description: This function reads opc value for campaign and fills 
        'the corresponding value in the structure for each unit
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
  
            Dim iItemCnt As Integer = 0
            Dim iParaCnt As Integer
            ReDim struOPC(UBound(strArrUnits) - 1)


            ReDim oOPCCampResult(UBound(oOPCCampItems))

            iParaCnt = 0
            Dim bFlag As Boolean = False

            For iItemCnt = 0 To UBound(oOPCCampItems)
                oOPCCampResult(iItemCnt) = 0
                Try

                    oOPCCampItems(iItemCnt).Read(OPCDotNetAutomation.OPCDataSource.OPCDevice, oOPCCampResult(iItemCnt))

                    Threading.Thread.Sleep(20) '09/08/2012 previous value 10
                Catch ex As Exception
                    '09/08/2012
                    iOpcReadError = iOpcReadError + 1
                    EventViewerLog("ReadOPCValues: Read failed for item " & oOPCCampItems(iItemCnt).ItemID, "Error")
                End Try

                If (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(0)) = True) Then
                    struOPC(iParaCnt).strBatchId = oOPCCampResult(iItemCnt)
                    bFlag = True
                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(1)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strRecipe = oOPCCampResult(iItemCnt).ToString().ToUpper

                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(2)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strFormula = oOPCCampResult(iItemCnt).ToString().ToUpper

                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(3)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strEquipmentTrain = oOPCCampResult(iItemCnt).ToString().ToUpper

                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(4)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strStartCommand = oOPCCampResult(iItemCnt).ToString().ToUpper

                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(5)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strStatus = oOPCCampResult(iItemCnt).ToString().ToUpper

                ElseIf (oOPCCampItems(iItemCnt).ItemID.Contains(strArrCamp(6)) = True) And bFlag = True Then
                    struOPC(iParaCnt).strComplete = oOPCCampResult(iItemCnt).ToString().ToUpper
                    bFlag = False
                End If
                If (bFlag = False) Then
                    iParaCnt = iParaCnt + 1
                End If
            Next
            
            ReadOPCValues = True

        Catch ex As Exception
            EventViewerLog("ReadOPCValues " & ex.Message, "Error")
            ReadOPCValues = False
        Finally
        End Try
    End Function
    Public Function ReadOPCValuesWatchDog() As Boolean

        '-------------------------------------------------------------------
        'Description: This function reads opc value for watch dog 
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Dim iItemCnt As Integer
        Try

            If (bOPCItemWatchDogResult = True) Then
                ReDim oOPCWatchDogResult(UBound(oOPCWatchDogItems))
                For iItemCnt = 1 To UBound(oOPCWatchDogItems) - 1
                    Try
                        oOPCWatchDogItems(iItemCnt).Read(OPCDotNetAutomation.OPCDataSource.OPCDevice, oOPCWatchDogResult(iItemCnt))
                        Threading.Thread.Sleep(10)
                    Catch ex As Exception
                        ReadOPCValuesWatchDog = False
                        EventViewerLog("ReadOPCValuesWatchDog: " & oOPCWatchDogItems(iItemCnt).ItemID & "  " & ex.Message, "Error")
                        Exit Function
                    End Try
                Next
                ReadOPCValuesWatchDog = True
            End If
        Catch ex As Exception
            EventViewerLog("ReadOPCValuesWatchDog: " & oOPCWatchDogItems(iItemCnt).ItemID & "  " & ex.Message, "Error")
            ReadOPCValuesWatchDog = False
        End Try
    End Function
    Public Function CheckForStartCommand(ByVal iStructItemCnt As Integer) As Boolean
        '-------------------------------------------------------------------
        'Description: This function reads Start Command opc value  
        'Output: Returns True if value read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
            If (struOPC(iStructItemCnt).strStartCommand = "1") Or (UCase(struOPC(iStructItemCnt).strStartCommand) = "TRUE") Then
                CheckForStartCommand = True
            Else
                CheckForStartCommand = False
            End If
            If (bDebug = True) Then
                EventViewerLog("CheckForStartCommand: " & CheckForStartCommand, "Message")
            End If
        Catch ex As Exception
            CheckForStartCommand = False
        Finally
        End Try
    End Function
    Public Function ValidateAndCreateCampaign(ByVal structCnt As Integer) As Boolean
        '-------------------------------------------------------------------
        'Description: This function reads opc value  
        'Output: Returns True if value read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        If (bDebug = True) Then
            EventViewerLog("ValidateAndCreateCampaign: Declaring objects", "Message")
        End If

        Dim objClient As New DVBCTRLCAMPAIGNMGRLib.DVBCMClient

        Dim vCampa As New Object

        Dim objCampaignEdit As DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignEdit4


        Dim objExecInfo As DVBCTRLCAMPAIGNMGRLib.DVBCMExecInfo
        Dim objExecInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3
        'Set the Executive info object

        Dim objExecRecipeInfo As DVBCTRLCAMPAIGNMGRLib.DVBCMExecRecipeInfo

        Dim objRecipeEdit As DVBCTRLCAMPAIGNMGRLib.DVBCMRecipeEdit
        Dim objBatchEdit As DVBCTRLCAMPAIGNMGRLib.DVBCMBatchEdit

        Dim objUnitName() As String
        
        Dim objStepName() As String
        Dim strMessage As String = ""

        Try


            EventViewerLog("ValidateAndCreateCampaign: Connecting to.." & strNodeName, "Message")
            Try
                'Connect
                objClient.Connect(strNodeName, False) '(My.Computer.Name, False)
            Catch ex As Exception
                EventViewerLog(ex.Message, "ERROR")
            End Try
            If (objClient.Connected = False) Then
                EventViewerLog("ValidateAndCreateCampaign: Invalid Node Name in cfg file.", "Error")
                Exit Function
            End If
            If (bDebug = True) Then
                EventViewerLog("ValidateAndCreateCampaign: Campaign Connect", "Message")
            End If
            Try
                Dim bValidCampName As Boolean = False
                'Validate Campaign Name
                bValidCampName = ValidateCampaignName(struOPC(structCnt).strBatchId)
                If (bValidCampName = False) Then
                    strMessage = "Invalid Campaign Name"
                    GoTo LogEvent
                End If
                Dim objCampList() As Object
                Dim iCmpCnt As Integer
                objCampList = objClient.CampaignList()

                Dim objCampaignInfo As DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignInfo3
                Dim objBInfo As DVBCTRLCAMPAIGNMGRLib.IDVBCMBatchInfo

                For iCmpCnt = 0 To UBound(objCampList)
                    If (objCampList(iCmpCnt) = struOPC(structCnt).strBatchId) Then

                        objCampaignInfo = objClient.CampaignInfo(struOPC(structCnt).strBatchId)
                        objBInfo = objCampaignInfo.BatchInfo(struOPC(structCnt).strBatchId)

                        If (objBInfo.State = DVBCTRLCAMPAIGNMGRLib.DVBCMBATCHSTATE.dvbcmBatchStateCompleteNoError) Then
                            objCampaignEdit = objClient.CampaignEdit(struOPC(structCnt).strBatchId)

                            objClient.RemoveCampaign(struOPC(structCnt).strBatchId)
                        Else
                            strMessage = "Campaign Already Exist"
                            GoTo LogEvent
                        End If

                    End If

                Next

                'If campiagn name is valid create it else log it
                objCampaignEdit = objClient.NewCampaign(struOPC(structCnt).strBatchId)

                If (bDebug = True) Then
                    EventViewerLog("ValidateAndCreateCampaign: New Campaign ", "Message")
                End If
            Catch ex As Exception
                EventViewerLog(struOPC(structCnt).strBatchId & " " & ex.Message, "Error")
                ValidateAndCreateCampaign = False
                If (ex.Message.Contains("Campaign already exists.") = True) Then
                    strMessage = "Campaign Already Exist" ''ex.Message
                Else
                    strMessage = "Other"
                End If
                GoTo LogEvent
            Finally
            End Try


            Dim bSetCampAttr As Boolean
            If (bDebug = True) Then
                EventViewerLog("SetCampaignAttributes", "Message")
            End If
            'Set campaing attributes i.e. suffix="",prefix="" etc....
            bSetCampAttr = SetCampaignAttributes(objCampaignEdit)
            If (bSetCampAttr = False) Then
                EventViewerLog("Campaign Attributes Not Set.", "Error")
                ValidateAndCreateCampaign = False
                strMessage = "Campaign Attributes Not Set"
                GoTo LogEvent
            End If
            'Upgrade V11
            'objExecInfo = objClient.ExecutiveInfo(strNodeName) '(My.Computer.Name)
            'objExecInfo3 = objClient.ExecutiveInfo(strNodeName)
            objExecInfo = objClient.ExecutiveInfo(strBExecName) '(My.Computer.Name)
            objExecInfo3 = objClient.ExecutiveInfo(strBExecName)

            Dim bCheckRecipe As Boolean = False

            'Check if Recipe Exist 
            bCheckRecipe = CheckRecipeExist(objExecInfo, struOPC(structCnt).strRecipe)

            If (bCheckRecipe = False) Then
                EventViewerLog("Invalid Recipe: " & struOPC(structCnt).strRecipe & " for " & struOPC(structCnt).strBatchId, "Error")
                ValidateAndCreateCampaign = False
                strMessage = "Invalid Recipe"
                GoTo LogEvent
            End If

            objRecipeEdit = objCampaignEdit.RecipeEdit()
            objExecRecipeInfo = objExecInfo.ExecutiveRecipeInfo(struOPC(structCnt).strRecipe, )

            Dim bCheckEquipment As Boolean = False
            bCheckEquipment = CheckEqipmentTrainExist(struOPC(structCnt).strEquipmentTrain, struOPC(structCnt).strRecipe, objExecInfo3)

            'Check If Equipment Train exist
            If (bCheckEquipment = False) Then
                EventViewerLog("Invalid Equipment Train: " & struOPC(structCnt).strEquipmentTrain & " for " & struOPC(structCnt).strRecipe, "Error")
                ValidateAndCreateCampaign = False
                strMessage = "Invalid Equipment Train"
                GoTo LogEvent
            End If


            Dim objRecipInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo3
            Dim objExeInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3
            'Upgrade V11
            'objExeInfo3 = objClient.ExecutiveInfo(strNodeName)
            objExeInfo3 = objClient.ExecutiveInfo(strBExecName)
            objRecipInfo3 = objExeInfo3.ExecutiveRecipeInfo(struOPC(structCnt).strRecipe)
            objRecipInfo3.GetEqTrainBaseClass(strBaseClas, strBaseClsDesc)

            'Check if Formula Exist
            Dim bCheckFormula As Boolean = False
            bCheckFormula = CheckFromulaExist(objExecRecipeInfo, struOPC(structCnt).strFormula)

            If (bCheckFormula = True) Then
                objRecipeEdit.Formula = struOPC(structCnt).strFormula
            ElseIf (struOPC(structCnt).strFormula = "" Or struOPC(structCnt).strFormula = Chr(34) & Chr(34)) Then
                struOPC(structCnt).strFormula = ""
            ElseIf (bCheckFormula = False) Then
                EventViewerLog("Invalid Formula: " & struOPC(structCnt).strFormula & " for " & struOPC(structCnt).strRecipe, "Error")
                ValidateAndCreateCampaign = False
                strMessage = "Invalid Formula" '''& struOPC(structCnt).strFormula
                GoTo LogEvent
            End If


            Dim objRecipeEdit2 As DVBCTRLCAMPAIGNMGRLib.IDVBCMRecipeEdit2
            Dim objRecipeEdit3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMRecipeEdit3
            objRecipeEdit2 = objCampaignEdit.RecipeEdit()
            objRecipeEdit3 = objCampaignEdit.RecipeEdit()

            Try
                If (bRecipeWithoutEqTrain = False) Then
                    objRecipeEdit2.SetEqTrainInstance(struOPC(structCnt).strEquipmentTrain, "", strBaseClas, strBaseClsDesc)
                Else
                    bRecipeWithoutEqTrain = False
                End If
            Catch ex As Exception
                strMessage = "Other"
                GoTo LogEvent
            End Try
            objRecipeEdit.Name = struOPC(structCnt).strRecipe


            objRecipeEdit.Formula = struOPC(structCnt).strFormula
            'Upgrade V11
            'objRecipeEdit.Executive = strNodeName
            objRecipeEdit.Executive = strBExecName
            objRecipeEdit3.Name = struOPC(structCnt).strRecipe

            '---------------------------------------------------
            Dim objExecRecipeinfo2 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo2
            Dim objExexInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3
            Dim objBoundUnit() As Object
            Dim objClsBase() As Boolean
            Dim objAliasBase() As Boolean
            Dim strUnits() As String
            Dim lgUnitIDs() As Int32
            Dim strAreaNames() As String
            Dim objOutOFservice() As Boolean
            Dim iMode() As Int32
            Dim objAreaName() As String
            Dim i As Integer
            Dim objUnitId() As Int32
            Dim objAreaId() As Int32
            'Upgrade V11
            'objExexInfo3 = objClient.ExecutiveInfo(strNodeName)
            objExexInfo3 = objClient.ExecutiveInfo(strBExecName)
            objExecRecipeinfo2 = objExexInfo3.ExecutiveRecipeInfo(struOPC(structCnt).strRecipe)

            objExecRecipeinfo2.GetStepsAndBoundUnits(objStepName, objBoundUnit, objClsBase, objAliasBase, 3000)

            ReDim strUnits(UBound(objStepName))
            ReDim lgUnitIDs(UBound(objStepName))
            ReDim strAreaNames(UBound(objStepName))
            ReDim iMode(UBound(objStepName))

            For i = 0 To UBound(objStepName)
                If objAliasBase(i) = False Then
                    objExexInfo3.GetExecutiveUnitInfo2(objBoundUnit(i), objUnitName, objUnitId, objOutOFservice, objAreaName, objAreaId)
                    strUnits(i) = objUnitName(0)

                    strAreaNames(i) = objAreaName(0)
                Else
                    strUnits(i) = objBoundUnit(i)

                    strAreaNames(i) = "Unknown"
                End If
            Next i

            For i = 0 To UBound(objStepName)
                iMode(i) = 3 'From_policy
                lgUnitIDs(i) = -999
            Next
            Try
                objRecipeEdit3.SetUnitBindings_v103(objStepName, objBoundUnit, lgUnitIDs, iMode)
            Catch ex As Exception
                strMessage = "Other"
                GoTo LogEvent
            End Try


            '---------------------------------------------------
            ' objRecipeEdit.SetUnitBindings(objStepName, objUnitName, lUnitID)
            '---------------------------------------------------


            'Check if GID is online
            bGIDOnline = CheckGIDOnline()
            If (bGIDOnline = False) Then
                EventViewerLog("GID Is Offline", "Error")
                strMessage = "GID Is Offline"
                GoTo LogEvent
            End If
            If (bDeltaVStatus = True) Then
                Try
                    objCampaignEdit.SetupComplete()
                Catch ex As Exception
                    EventViewerLog("Create Campaign: lin no 768" & ex.Message, "Error")
                    strMessage = "Other"
                    GoTo LogEvent
                End Try

                Try
                    objBatchEdit = objCampaignEdit.NewBatch(struOPC(structCnt).strBatchId)

                    objBatchEdit.SetupComplete()

                    objCampaignEdit.AddBatch(objBatchEdit, False, False)


                Catch ex As Exception
                    EventViewerLog("Create Campaign : " & ex.Message, "Error")
                    strMessage = "Other" '"Create Campaign: " & ex.Message
                    GoTo LogEvent
                End Try

                If (objClient.Connected = True) Then
                    Try
                        'objClient.AddCampaign(objCampaignEdit, "Administrator", "deltav", "Administrator", "deltav", )
                        objClient.AddCampaign(objCampaignEdit, "", "", "", "", )
                        objCampaignEdit.UnLockEdit()
                        ''objCampaignEdit.SetExecutionMode4(False, True, False)
                        objCampaignEdit.SetExecutionMode4(False, False, True)
                        objCampaignEdit.SetAutoRemove3(False, False, True, 0)
                        'For auto remove uncomment below line
                        'objCampaignEdit.SetAutoRemove3(True, True, True, 1, "", "", "", "", "")
                        '----------------------------------
                        struOPC(structCnt).strStatus = "OK" '"Campaign Created"
                        strMessage = "OK"
                        struOPC(structCnt).strComplete = "1"
                        strMessageCampCreated = struOPC(structCnt).strBatchId & " Campaign Created."

                    Catch ex As Exception
                        If (ex.Message.Contains("Campaign Already Exists") = True) Then
                            strMessage = "Campaign Already Exist" ''ex.Message
                        Else
                            strMessage = "Other"
                        End If

                    End Try
                End If

LogEvent:       UpdateStatus(structCnt, strMessage)
                'struOPC(structCnt).strStatus = strMessage 'give proper message
                'struOPC(structCnt).strComplete = "1"
                'struOPC(structCnt).strStartCommand = "0"

                'If (structCnt = 0) Then
                '    oOPCCampItems(4).Write(struOPC(structCnt).strStartCommand)
                '    oOPCCampItems(5).Write(struOPC(structCnt).strStatus)
                '    oOPCCampItems(6).Write(struOPC(structCnt).strComplete)
                'Else
                '    oOPCCampItems(((((structCnt + 1) * 5) + (structCnt * 2)) - 1)).Write(struOPC(structCnt).strStartCommand)
                '    oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2)).Write(struOPC(structCnt).strStatus)
                '    oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2) + 1).Write(struOPC(structCnt).strComplete)
                'End If
                ValidateAndCreateCampaign = True
            End If
        Catch ex As Exception
            ValidateAndCreateCampaign = False

        Finally
            objClient.Disconnect()

        End Try



    End Function
    Public Function UpdateStatus(ByVal structCnt As Integer, ByVal strMessage As String) As Boolean
        Try
            struOPC(structCnt).strStatus = strMessage 'give proper message
            struOPC(structCnt).strComplete = "1"
            struOPC(structCnt).strStartCommand = "0"

            If (structCnt = 0) Then
                oOPCCampItems(4).Write(struOPC(structCnt).strStartCommand)
                oOPCCampItems(5).Write(struOPC(structCnt).strStatus)
                oOPCCampItems(6).Write(struOPC(structCnt).strComplete)
            Else
                oOPCCampItems(((((structCnt + 1) * 5) + (structCnt * 2)) - 1)).Write(struOPC(structCnt).strStartCommand)
                oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2)).Write(struOPC(structCnt).strStatus)
                oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2) + 1).Write(struOPC(structCnt).strComplete)
            End If
            UpdateStatus = True
        Catch ex As Exception
            EventViewerLog("Update Status: " & ex.Message, "Error")
            UpdateStatus = False

        End Try
    End Function
    Public Function SetCampaignAttributes(ByRef objCampaignEdit As DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignEdit4) As Boolean
        '-------------------------------------------------------------------
        'Description: This function sets the Campaign attributes 
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
            objCampaignEdit.EnterSetupMode()
            objCampaignEdit.Prefix = ""
            objCampaignEdit.Suffix = ""
            objCampaignEdit.Description = "From DeltaV MES Interface"
            objCampaignEdit.MaximumActiveBatches = 1
            SetCampaignAttributes = True
        Catch ex As Exception
            SetCampaignAttributes = False
        Finally
        End Try
    End Function
    Public Function ValidateCampaignName(ByVal strCampName As String) As Boolean
        '-------------------------------------------------------------------
        'Description: This function Validates Campaign name
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try

            If (strCampName.Contains("\") = True) Or (strCampName.Contains("/") = True) Or (strCampName.Contains(":") = True) Or (strCampName.Contains("*") = True) Or (strCampName.Contains("?") = True) Or (strCampName.Contains(Chr(34)) = True) Or (strCampName.Contains("<") = True) Or (strCampName.Contains(">") = True) Or (strCampName.Contains("|") = True) Or (strCampName.Contains("(") = True) Or (strCampName.Contains(")") = True) Or (strCampName.Contains(";") = True) Or (strCampName.Contains("[") = True) Or (strCampName.Contains("]") = True) Or (strCampName.Contains("\") = True) Or (strCampName.Contains("%") = True) Or (strCampName.Contains(",") = True) Or (strCampName.Contains("'") = True) Or (strCampName.Contains(",") = True) Or (strCampName.Contains("&") = True) Or (strCampName.Contains(" ") = True) Then
                ValidateCampaignName = False
            Else
                ValidateCampaignName = True
            End If
        Catch ex As Exception
            ValidateCampaignName = False
            Exit Function
        End Try


    End Function
    Public Function CheckRecipeExist(ByRef objExecInfo As DVBCTRLCAMPAIGNMGRLib.DVBCMExecInfo, ByVal strRecipe As String) As Boolean
        '-------------------------------------------------------------------
        'Description: This function check if recipe is valid or not 
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
            Dim iCnt As Integer
            Dim strRecipeList() As String
            strRecipeList = objExecInfo.ExecutiveRecipeList()
            For iCnt = 0 To UBound(strRecipeList)
                If (strRecipeList(iCnt) = strRecipe) Then
                    CheckRecipeExist = True
                    Exit For
                Else
                    CheckRecipeExist = False
                End If
            Next
        Catch ex As Exception
            CheckRecipeExist = False
        Finally
        End Try
    End Function
   

    Public Function CheckEqipmentTrainExist(ByVal strEquipmentTrain As String, ByVal strReciepName As String, ByRef objExeInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3) As Boolean
        '-------------------------------------------------------------------
        'Description: This function check  if Equipment train is valid (find the base class name and then decide) 
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Dim objRecipInfo3 As DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo3
        Dim strBCls As String
        Dim strDesc As String

        Dim strEQTrainDescCls As String
        Dim objEq() As Object
        Dim objEqListDesc() As Object
        Dim iCnt As Integer
        Try
            objRecipInfo3 = objExeInfo3.ExecutiveRecipeInfo(strReciepName)
            objRecipInfo3.GetEqTrainBaseClass(strBCls, strDesc)
            If (strBCls <> "") Then
                objExeInfo3.GetEqTrainList(strBCls, strEQTrainDescCls, objEq, objEqListDesc)
                If (objEq.Length > 0) Then
                    For iCnt = 0 To UBound(objEq)
                        If (objEq(iCnt) = strEquipmentTrain) Then
                            CheckEqipmentTrainExist = True
                            bRecipeWithoutEqTrain = False
                            Exit For
                        Else
                            CheckEqipmentTrainExist = False
                        End If
                    Next
                End If
            ElseIf (strBCls = "" And strReciepName <> "") Then
                CheckEqipmentTrainExist = True
                bRecipeWithoutEqTrain = True
            Else
                CheckEqipmentTrainExist = False
            End If

        Catch ex As Exception
            CheckEqipmentTrainExist = False
        Finally
        End Try
    End Function
    Public Function CheckFromulaExist(ByRef objExecRecipeInfo As DVBCTRLCAMPAIGNMGRLib.DVBCMExecRecipeInfo, ByVal strFormula As String) As Boolean
        '-------------------------------------------------------------------
        'Description: This function checks if formula is valid or not
        'Output: Returns True if values read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
            Dim iCnt As Integer
            Dim strArrFormula() As String
            strArrFormula = objExecRecipeInfo.FormulaList()
            If (strFormula = "") Then
                CheckFromulaExist = True
                Exit Function
            End If
            If (strArrFormula.Length = 0) Then
                CheckFromulaExist = True
                Exit Function
            End If

            For iCnt = 0 To UBound(strArrFormula)
                If (strArrFormula(iCnt) = strFormula) Then
                    CheckFromulaExist = True
                    Exit For
                Else
                    CheckFromulaExist = False
                End If
            Next
        Catch ex As Exception
            CheckFromulaExist = False
        Finally
        End Try
    End Function
    Public Function CheckGIDOnline() As Boolean
        '-------------------------------------------------------------------
        'Description: This function check is GID is online or not
        'Output: Returns True if value read successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
           
            If (oOPCWatchDogResult(2) = "0") Then
                bGIDOnline = True
                CheckGIDOnline = True
            Else
                CheckGIDOnline = False
            End If
          
        Catch ex As Exception
            CheckGIDOnline = False
        Finally
        End Try
    End Function

    Public Function EventViewerLog(ByVal strSource As String, ByVal strType As String) As Boolean
        '-------------------------------------------------------------------
        'Description :This function writes the message to the event viewer
        'Output: Returns True if message logged successfully
        '        Returns False if not
        '-------------------------------------------------------------------
        Try
            If (strSource = "") Then
                Exit Function
            End If
            Dim logError As String = "Application"
            If (Not (Diagnostics.EventLog.SourceExists("DeltaVMESInterfaceService"))) Then
                Diagnostics.EventLog.CreateEventSource("DeltaVMESInterfaceService", logError)
            End If
            If (UCase(strType) = "ERROR") Then
                Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Error)
            ElseIf (UCase(strType) = "MESSAGE") Then
                Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Information)
            Else
                Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Warning)
            End If

        Catch ex As Exception
        Finally
        End Try
    End Function
    Public Sub WatchDogThread()
        '-------------------------------------------------------------------
        'Description :This function will be a thread called every 10 seconds 
        'Output:Returns True if thread executed successfully
        '       Returns False if not
        '-------------------------------------------------------------------
        Dim OldTime As DateTime
        Dim cOPCWatchDog As New clsOPC
        Try
            'Check if FRSOPCDV.exe is running or not
FRSOPCDV:   bFrsopcdv = CheckFRSOPCDV()

            If (bFrsopcdv = False) Then
                Threading.Thread.Sleep(60000)
                GoTo FRSOPCDV
            End If
            If (bDebug = True) Then
                EventViewerLog("CheckFRSOPCDV Completed", "Message")
            End If

            Try

                If (iStartWatchCnt = 0) Then
                    'Connect to OPC server and add Gropp to it
                    bOPCItemWatchDogResult = cOPCWatchDog.Start_OPC(oOPCServerWD, oOPCWatchDogControlGroup, oOPCWatchDogItems, strArrWatchDog, "DVWatchDog")

                    iStartWatchCnt = 1

                End If
            Catch ex As Exception
                EventViewerLog("Start OPC: WatchDog Thread " & ex.Message, "Error")

                Exit Sub
            End Try
            OldTime = DateTime.Now()
            While bterminate = False And iStartWatchCnt = 1

                Try

                    If DateDiff(DateInterval.Second, OldTime, DateTime.Now()) > 10 Then

                        Dim bWriteWDI As Boolean

                        bWriteWDI = WriteWatchDogInterface()
                        If (bWriteWDI = True) Then
                            Dim bReadWatchDogDeltaV As Boolean

                            bReadWatchDogDeltaV = ReadWatchDogDeltaV()
                            If (bReadWatchDogDeltaV = True) Then
                                If (bDVPrev <> bDeltaVStatus) Then
                                    If (bDeltaVStatus = True) Then
                                        EventViewerLog("DeltaV is Online.", "Message")
                                    Else
                                        EventViewerLog("DeltaV is Offline.", "Error")
                                    End If

                                End If
                            End If
                        End If
                        OldTime = DateTime.Now()
                    End If

                Catch ex As Exception
                    EventViewerLog("WatchDogThread: " & ex.Message, "Error")

                End Try
                Threading.Thread.Sleep(10000)
            End While

        Catch ex As Exception
            EventViewerLog("WatchDogThread: " & ex.Message, "Error")
        Finally
            '21/08/2012
            oOPCServerWD.Disconnect()

        End Try
    End Sub

    Public Function WriteWatchDogInterface() As Boolean
        '-------------------------------------------------------------------
        'Description :This function will set the Watch Dog Interface parameter
        'Output:Returns True if thread executed successfully
        '       Returns False if not
        '-------------------------------------------------------------------

        Dim iCnt As Integer
        Try
            For iCnt = 0 To UBound(oOPCWatchDogItems) - 1

                If (oOPCWatchDogItems(iCnt).ItemID.Contains("/WATCHDOG_INTERFA.CV") = True) Then
                    oOPCWatchDogItems(iCnt).Write("1")
                    Threading.Thread.Sleep(10)
                    WriteWatchDogInterface = True

                    Exit For
                End If
            Next
   
        Catch ex As Exception
            EventViewerLog("WriteWatchDogInterface: " & oOPCWatchDogItems(iCnt).ItemID, "Error")
            WriteWatchDogInterface = False
        Finally
        End Try
    End Function
    Public Function ReadWatchDogDeltaV() As Boolean
        '-------------------------------------------------------------------
        'Description :This function will read the Watch Dog DeltaV parameter
        'Output:Returns True if thread executed successfully
        '       Returns False if not
        '-------------------------------------------------------------------

        Dim strValue As String
        Dim bReadValue As Boolean
        Try
            'Read OPC values for Watch dog.
            bReadValue = ReadOPCValuesWatchDog()
            If (bReadResult = False) Then
                ReadWatchDogDeltaV = False
                EventViewerLog("ReadWatchDogDeltaV: Read DeltaV Watch Dog Failed. ", "Error")
                Exit Function
            End If
            strValue = oOPCWatchDogResult(1) 'Check if WATCHDOGS/WATCHDOG_DELTAV.CV is 1
            If (strValue = "1") Then
                oOPCWatchDogItems(1).Write("0")
                bDVPrev = bDeltaVStatus
                bDeltaVStatus = True
            Else
                bDVPrev = bDeltaVStatus
                bDeltaVStatus = False
            End If
            ReadWatchDogDeltaV = True

        Catch ex As Exception
            ReadWatchDogDeltaV = False
            EventViewerLog("ReadWatchDogDeltaV: Read DeltaV Watch Dog Failed. ", "Error")
        Finally
        End Try
    End Function

 
    ''Public Function RegistryCheck(ByRef strByPassDV As String, ByRef strByPassCamp As String, ByRef strUserName As String, ByRef strpassword As String) As Boolean
    ''    '-------------------------------------------------------------------
    ''    'Description :This function checks Registry to decide wheather to Bypass Deltav
    ''    '             ang CreateCampaign or not and sets the str
    ''    'Output:Returns True Check is done successfully
    ''    '       Returns False if not
    ''    '-------------------------------------------------------------------

    ''    Dim lmKey, FRSIKey As RegistryKey
    ''    Dim DVMESKey As RegistryKey

    ''    Try
    ''        lmKey = Registry.LocalMachine
    ''        lmKey = lmKey.OpenSubKey("SOFTWARE", True)
    ''        FRSIKey = lmKey.OpenSubKey("FRSI", True)

    ''        If (IsNothing(FRSIKey) = False) Then

    ''            DVMESKey = FRSIKey.OpenSubKey("DeltaVMESInterface", True)
    ''            If (IsNothing(DVMESKey) = False) Then
    ''                strByPassDV = DVMESKey.GetValue("ByPassDeltaV")
    ''                strByPassCamp = DVMESKey.GetValue("ByPassCampaign")
    ''            Else

    ''                DVMESKey = FRSIKey.CreateSubKey("DeltaVMESInterface", RegistryKeyPermissionCheck.ReadWriteSubTree)
    ''                DVMESKey.SetValue("ByPassDeltaV", "0", RegistryValueKind.String)
    ''                DVMESKey.SetValue("ByPassCampaign", "0", RegistryValueKind.String)
    ''                strByPassDV = DVMESKey.GetValue("ByPassDeltaV")
    ''                strByPassCamp = DVMESKey.GetValue("ByPassCampaign")
    ''            End If
    ''        Else
    ''            FRSIKey = lmKey.CreateSubKey("FRSI")
    ''            DVMESKey = FRSIKey.OpenSubKey("DeltaVMESInterface", True)
    ''            If (IsNothing(DVMESKey) = False) Then
    ''                strByPassDV = DVMESKey.GetValue("ByPassDeltaV")
    ''                strByPassCamp = DVMESKey.GetValue("ByPassCampaign")
    ''            Else

    ''                DVMESKey = FRSIKey.CreateSubKey("DeltaVMESInterface", RegistryKeyPermissionCheck.ReadWriteSubTree)
    ''                DVMESKey.SetValue("ByPassDeltaV", "0", RegistryValueKind.String)
    ''                DVMESKey.SetValue("ByPassCampaign", "0", RegistryValueKind.String)
    ''                strByPassDV = DVMESKey.GetValue("ByPassDeltaV")
    ''                strByPassCamp = DVMESKey.GetValue("ByPassCampaign")
    ''            End If
    ''        End If
    ''        RegistryCheck = True
    ''    Catch ex As Exception
    ''        RegistryCheck = False
    ''    Finally
    ''        lmKey = Nothing
    ''        FRSIKey = Nothing
    ''        DVMESKey = Nothing

    ''    End Try
    ''End Function
End Module
