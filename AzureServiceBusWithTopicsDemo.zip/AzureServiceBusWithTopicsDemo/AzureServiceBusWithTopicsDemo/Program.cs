﻿using Microsoft.Azure.ServiceBus;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AzureServiceBusWithTopicsDemo
{
    class Program
    {
        ITopicClient topicClient;
        const string ServiceBusConnectionString = "Endpoint=sb://trialservicebusss.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=70JDjrWoYUPsJ6bCj1qoluypw3zXN0qInSYZrsAOY3I=";
        const string TopicName = "testtopic";
        ISubscriptionClient subscriptionClient;
        private Program()
        {    
            topicClient = new TopicClient(ServiceBusConnectionString, TopicName);

            subscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, "subc");
        }
        static void Main(string[] args)
        {
            try
            {
                Program p = new Program();
                p.SendMessage().Wait();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private  async Task SendMessage()
        {
            string messageBody = string.Empty;

            Message message = new Message();
            for (int i = 0; i < 5; i++)
            {
                messageBody = $"Message {i.ToString()}";
                message.Body = Encoding.UTF8.GetBytes(messageBody);
                //In Session Enabled case add the session id to message
                // message.SessionId = Guid.NewGuid().ToString();
  
                await topicClient.SendAsync(message);
            }

            await topicClient.CloseAsync();

        }

        private void ReadMessage()
        {   
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                // Maximum number of concurrent calls to the callback ProcessMessagesAsync(), set to 1 for simplicity.
                // Set it according to how many messages the application wants to process in parallel.
                MaxConcurrentCalls = 1,

                // Indicates whether the message pump should automatically complete the messages after returning from user callback.
                // False below indicates the complete operation is handled by the user callback as in ProcessMessagesAsync().
                AutoComplete = false
            };

            // Register the function that processes messages.
            subscriptionClient.RegisterMessageHandler(ProcessMessagesAsync, messageHandlerOptions);           
        }

        private Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine(exceptionReceivedEventArgs.Exception.Message);
            return Task.CompletedTask;
        }

        private async Task ProcessMessagesAsync(Message message, CancellationToken token)
        {
            Console.WriteLine(Encoding.UTF8.GetString(message.Body));

            await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);
        }

        //Session Enabled Section

        private void ReadSessionEnabledMessage()
        {
            SessionHandlerOptions sessionHandlerOptions = new SessionHandlerOptions(ExceptionReceivedHandler)
            {
                MaxConcurrentSessions = 100,
                AutoComplete = true
                //// We don't use the CompleteAsync() method.

                //// await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);
            };

            subscriptionClient.RegisterSessionHandler(ProcessMessagesInSessionAsync, sessionHandlerOptions);
        }

        private static async Task ProcessMessagesInSessionAsync(IMessageSession messageSession, Message message, CancellationToken token)
        {
            Console.WriteLine($"Received message: SequenceNumber:{message.SystemProperties.SequenceNumber} Body:{Encoding.UTF8.GetString(message.Body)}");

            await Task.CompletedTask;

            //// We don't use the CompleteAsync() method.

            //// await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);

        }
    }
}
