﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
//using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
//using System.Threading.Tasks;
using Microsoft.VisualBasic;
using Microsoft.Win32;
using OPCDotNetAutomation;

namespace DeltaVMESInterfaceCSharp
{
    internal static class modDVMES
    {
        internal class structopc
        {
            public string strBatchId;
            public string strRecipe;
            public string strFormula;
            public string strEquipmentTrain;
            public string strStartCommand;
            public string strStatus;
            public string strComplete;
        }
        public static bool bDebug = false;
        public static string strUserName;
        public static string strPassword;
        public static string strNodeName;
        // Upgrade V11
        public static string strBExecName;
        public static bool bReadResult;
        public static bool bFrsopcdv;
        public static bool bCampMgr;
        public static bool bCreateTagList;
        public static string[] strArrWatchDog;
        public static string[] strArrCamp;
        public static string[] strArrUnits;
        public static structopc[] struOPC;
        public static string[] strArrCampUnits;
        public static bool bOPCItemWatchDogResult = false;
        public static bool bOPCItemCampResult = false;
        public static OPCDotNetAutomation.OPCItem[] oOPCCampItems;
        public static OPCDotNetAutomation.OPCItem[] oOPCWatchDogItems;
        public static string[] strArrPara;
        public static string strPara;
        //public static object oOPCCampResult;
        public static List<dynamic> oOPCCampResult;
        //public static object oOPCWatchDogResult;
        public static List<dynamic> oOPCWatchDogResult;
        public static bool bDeltaVStatus = false;
        public static bool bDVPrev = false;
        public static bool bGIDOnline = false;

        public static System.Threading.Thread thCampaign = new System.Threading.Thread(CampaignThread);
        public static System.Threading.Thread thWatchDog = new System.Threading.Thread(WatchDogThread);

        public static bool bterminate = false;
        public static int iStartCampCnt = 0;
        public static int iStartWatchCnt = 0;
        public static OPCDotNetAutomation.OPCGroup oOPCCampControlGroup;
        public static OPCDotNetAutomation.OPCGroup oOPCWatchDogControlGroup;
        // 09/08/2012
        public static OPCDotNetAutomation.OPCServer oOPCServerCamp;
        public static OPCDotNetAutomation.OPCServer oOPCServerWD;
        // ***
        public static string strBaseClas;
        public static string strBaseClsDesc;
        public static bool bRecipeWithoutEqTrain = false;
        // Public bDebug As Boolean = True
        public static string strMessageCampCreated = "";
        // 09/08/2012
        public static int iOpcReadError;


        public static bool CheckFRSOPCDV()
        {
            // -------------------------------------------------------------------
            // Description: This function checks if FRSOPCDV.exe is running or not
            // Output: Returns True if running
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkFRSOPCDV = false;
            try
            {
                System.Diagnostics.Process[] iProc;
                int i;
                try
                {
                    // ----------------------------------------
                    // Get all Processes running
                    // ----------------------------------------
                    iProc = Process.GetProcesses();
                    //CheckFRSOPCDV = false;
                    // ----------------------------------------
                    // Check if FRSOPCDV.exe is running or not
                    // FRSOPCDV.exe is used for OPC Read/Write.
                    // ----------------------------------------
                    for (i = 0; i <= iProc.Length - 1; i++)
                    {
                        if (iProc[i].ProcessName.ToUpper() == "FRSOPCDV")
                            checkFRSOPCDV = true;
                    }
                }
                catch (Exception ex)
                {
                    checkFRSOPCDV = false;
                }

            }
            catch (Exception ex)
            {
                checkFRSOPCDV = false;
            }

            finally
            {
            }
            return checkFRSOPCDV;
        }
        public static bool CheckCampMagr()
        {
            // -------------------------------------------------------------------
            // Description: This function checks if CAMPAIGNMGR.exe is running or not
            // Output: Returns True if running
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkCampMagr = false;
            try
            {
                System.Diagnostics.Process[] iProc;
                int i;
                try
                {
                    // ----------------------------------------
                    // Get all Processes running
                    // ----------------------------------------
                    iProc = Process.GetProcesses();
                    //CheckCampMagr = false;
                    // ----------------------------------------
                    // Check if CAMPAIGNMGR.exe is running or not
                    // CAMPAIGNMGR.exe is used to create campaign.
                    // ----------------------------------------
                    for (i = 0; i <= iProc.Length - 1; i++)
                    {
                        if (iProc[i].ProcessName.ToUpper() == "dvbcampaignmgr".ToUpper())
                        {
                            checkCampMagr = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    checkCampMagr = false;
                }
                return checkCampMagr;

            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public static bool ReadTagConfigurationFile()
        {
            // -------------------------------------------------------------------
            // Description: This function reads the Tag configuration file 
            // Adds items in respective array (CreateCampaign/WatchDog)   
            // Output: Returns True if file read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool readTagConfigurationFile = false;
            try
            {

                if (File.Exists(System.Windows.Forms.Application.StartupPath + @"\DeltaVMESInterface.cfg") == true)
                {
                    StreamReader frConfig = new StreamReader(System.Windows.Forms.Application.StartupPath + @"\DeltaVMESInterface.cfg", false);
                    string strWatchDogConfig = "";
                    string strTextLine;
                    string strCampConfig = "";
                    string strUnits = "";
                    string strDebug = "";
                    while (frConfig.EndOfStream == false)
                    {
                        strTextLine = frConfig.ReadLine();
                        if ((strTextLine.Contains("NODE NAME:") == true))
                        {
                            strNodeName = strTextLine.Split(':').GetValue(1).ToString();
                            if ((strNodeName == ""))
                            {
                                EventViewerLog("Invalid Node Name in cfg file", "Error");
                                return readTagConfigurationFile;
                            }
                        }
                        else if ((strTextLine.Contains("BEXEC NAME:") == true))
                        {
                            strBExecName = strTextLine.Split(':').GetValue(1).ToString();
                            if ((strBExecName == ""))
                            {
                                EventViewerLog("Invalid Batch Exec Name in cfg file", "Error");
                                return readTagConfigurationFile;
                            }
                        }
                        else if ((strTextLine.Contains("DEBUG") == true))
                        {
                            strDebug = strTextLine.Split(':').GetValue(1).ToString();
                            if ((strDebug == "1"))
                                bDebug = true;
                            else
                                bDebug = false;
                        }
                        else if ((strTextLine.Contains("*WATCH DOG PARAMETERS*") == true))
                        {
                            strTextLine = frConfig.ReadLine();
                            while (strTextLine.Contains(";*") == false)
                            {
                                if ((strTextLine.Contains(":") == true))
                                    strWatchDogConfig = strWatchDogConfig + strTextLine.Split(':').GetValue(1) + ",";
                                strTextLine = frConfig.ReadLine();
                            }
                        }
                        else if ((strTextLine.Contains("*CREATE CAMPAIGN PARAMETERS*") == true))
                        {
                            strTextLine = frConfig.ReadLine();
                            while (strTextLine.Contains(";*") == false)
                            {
                                if ((strTextLine.Contains(":") == true))
                                {
                                    strPara = strPara + strTextLine.Split(':').GetValue(0) + ",";
                                    strCampConfig = strCampConfig + strTextLine.Split(':').GetValue(1) + ",";
                                    strTextLine = frConfig.ReadLine();
                                }
                            }
                        }
                        else if ((strTextLine.Contains("*UNITS*") == true))
                        {
                            strTextLine = frConfig.ReadLine();
                            while (strTextLine.Contains(";*") == false)
                            {
                                strUnits = strUnits + strTextLine + ",";
                                strTextLine = frConfig.ReadLine();
                            }
                        }
                    }

                    frConfig.Close();

                    if ((strWatchDogConfig != ""))
                    {
                        if ((strWatchDogConfig.Contains(",") == true))
                            strArrWatchDog = strWatchDogConfig.Split(',');
                    }
                    if ((strCampConfig != ""))
                    {
                        if ((strCampConfig.Contains(",") == true))
                            strArrCamp = strCampConfig.Split(',');
                    }
                    if ((strPara != ""))
                    {
                        if ((strPara.Contains(",") == true))
                            strArrPara = strPara.Split(',');
                    }
                    if ((strUnits != ""))
                    {
                        if ((strUnits.Contains(",") == true))
                            strArrUnits = strUnits.Split(',');
                    }
                    readTagConfigurationFile = true;
                }
                else
                {
                    EventViewerLog("Invalid cfg file", "Error");
                    readTagConfigurationFile = true;
                }
            }
            catch (Exception ex)
            {
                readTagConfigurationFile = false;
            }
            finally
            {
            }
            return readTagConfigurationFile;
        }

        public static bool CreateTagList()
        {
            // -------------------------------------------------------------------
            // Description: This function creates the tag list for Create Campaign 
            // and watch dog
            // Output:Returns True if tag craeted successfully
            // Returns False if not
            // -------------------------------------------------------------------
            try
            {
                int iCampCnt;
                int iUnitCnt;
                int iItemCnt = 0;

                //strArrCampUnits = new string[Information.UBound(strArrUnits) * Information.UBound(strArrCamp) - 1 + 1];
                strArrCampUnits = new string[(strArrUnits.Length - 1) * (strArrCamp.Length - 1) - 1 + 1];
                for (iUnitCnt = 0; iUnitCnt <= strArrUnits.Length - 2; iUnitCnt++)  //for (iUnitCnt = 0; iUnitCnt <= Information.UBound(strArrUnits) - 1; iUnitCnt++)
                {
                    for (iCampCnt = 0; iCampCnt <= strArrCamp.Length - 2; iCampCnt++)
                    {
                        strArrCampUnits[iItemCnt] = strArrUnits[iUnitCnt] + "/" + strArrCamp[iCampCnt];
                        iItemCnt = iItemCnt + 1;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
            }
        }

        public static void CampaignThread()
        {
            // -------------------------------------------------------------------
            // Description: This function will be a thread called every 30 seconds 
            // Output:Returns True if thread executed successfully
            // Returns False if not
            // -------------------------------------------------------------------
            DateTime OldTime;
            clsOPC cOPCCampa = new clsOPC();
            try
            {
                // Check if FRSOPCDV.exe is running
                //CheckFrsop:
                //    ;
                //    if ((bFrsopcdv == false))
                //    {
                //        System.Threading.Thread.Sleep(60000);
                //        goto CheckFrsop;
                //    }
                CheckFrsop();

                // Check if dvbcampaignmgr.exe 'Campaign manager service' is running or not
                // If Campaign Manager Service is not running log it every 1 minute in Event Viewer
                //CampMgr:
                //    ;
                //    bCampMgr = CheckCampMagr();

                //    if ((bCampMgr == false))
                //    {
                //        EventViewerLog("DeltaVMESInterface Waiting for DeltaV Campaign Manager Service to start...", "Warning");
                //        System.Threading.Thread.Sleep(60000);
                //        goto CampMgr;
                //    }
                CampMgr();
                if ((bDebug == true))
                    EventViewerLog("CheckCampMagr Completed", "Message");
                try
                {
                    if ((iStartCampCnt == 0))
                    {
                        // Connect to OPC Server if not connected and create group
                        bOPCItemCampResult = cOPCCampa.Start_OPC(ref oOPCServerCamp, ref oOPCCampControlGroup, ref oOPCCampItems, strArrCampUnits, "OPCCampaign");

                        iStartCampCnt = 1;
                    }
                }
                catch (Exception ex)
                {
                    EventViewerLog("Start OPC: Campaign Thread" + ex.Message, "Error");
                    return;
                }
                OldTime = DateTime.Now;
                iOpcReadError = 0;
                while (bterminate == false & iStartCampCnt == 1)
                {

                    // Check time interval
                    //if (DateTime.DateDiff(DateInterval.Second, OldTime, DateTime.Now) < 30)  

                    if ((DateTime.Now - OldTime).TotalSeconds > 30)
                    { // goto CheckTime;
                        if ((bDebug == true))
                            EventViewerLog("Campaign Thread: Executing ", "Message");
                        bool bReadVal = false;

                        // If OPC read error disconnect and reconnect to OPC server 09/08/12
                        if ((iOpcReadError >= 10))
                        {
                            if ((bDebug == true))
                                EventViewerLog("Restarting OPC connection: Campaign Thread", "Message");
                            oOPCServerCamp.Disconnect();
                            // reinit error counter
                            iOpcReadError = 0;
                            try
                            {
                                // Check if FRSOPCDV.exe is running
                                //CheckFrsop2:
                                //    ;
                                //    if ((bFrsopcdv == false))
                                //    {
                                //        System.Threading.Thread.Sleep(60000);
                                //        goto CheckFrsop2;
                                //    }
                                CheckFrsop2();
                                    oOPCCampControlGroup = null;
                                oOPCServerCamp = null;
                                oOPCCampItems = new OPCDotNetAutomation.OPCItem[1];
                                // Connect to OPC Server and create group
                                bOPCItemCampResult = cOPCCampa.Start_OPC(ref oOPCServerCamp, ref oOPCCampControlGroup, ref oOPCCampItems, strArrCampUnits, "OPCCampaign");
                            }
                            catch (Exception ex)
                            {
                                EventViewerLog("Restart OPC: Campaign Thread" + ex.Message, "Error");
                                return;
                            }
                        }
                        // Read OPC Tag values i.e UP001_Value.cv,UP002_Value.cv etc...
                        bReadVal = ReadOPCValues();

                        bool bCheckStartCommand = false;
                        int iStructCnt;

                        for (iStructCnt = 0; iStructCnt < struOPC.Length; iStructCnt++)   ///for (iStructCnt = 0; iStructCnt <= Information.UBound(struOPC); iStructCnt++)
                        {
                            if ((bDebug == true))
                                EventViewerLog("Campaign Thread: Checking for start command ", "Message");
                            bCheckStartCommand = CheckForStartCommand(iStructCnt);
                            if ((bDebug == true))
                                EventViewerLog("Campaign Thread: Start command status " + bCheckStartCommand, "Message");

                            // If bCheckStartCommand = True And (UCase(struOPC(iStructCnt).strComplete) = "FALSE" Or struOPC(iStructCnt).strComplete = "0") Then
                            if (bCheckStartCommand == true)
                            {
                                bCampMgr = CheckCampMagr();
                                if ((bCampMgr == false))
                                {
                                    EventViewerLog("DeltaVMESInterface Waiting for DeltaV Campaign Manager Service to start...", "Warning");
                                    UpdateStatus(iStructCnt, "Campaign Manager is offline");
                                }
                                else
                                {
                                    bool bStatus = false;
                                    if ((bDebug == true))
                                        EventViewerLog("Campaign Thread: Validating Inputs ", "Message");
                                    bStatus = ValidateAndCreateCampaign(iStructCnt);
                                    if ((bStatus == true))
                                        EventViewerLog(strMessageCampCreated, "Message");
                                }
                                bCheckStartCommand = false;
                            }
                        }

                        OldTime = DateTime.Now;
                    }
                //CheckTime:
                //    ;
                    System.Threading.Thread.Sleep(10000);
                }
            }
            catch (Exception ex)
            {
                EventViewerLog(ex.Message, "Error");
            }
            finally
            {
                // 21/08/2012 
                oOPCServerCamp.Disconnect();
            }
        }


        public static bool ReadOPCValues()
        {
            // -------------------------------------------------------------------
            // Description: This function reads opc value for campaign and fills 
            // the corresponding value in the structure for each unit
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            try
            {
                int iItemCnt = 0;
                int iParaCnt;
                //struOPC = new structopc[Information.UBound(strArrUnits) - 1];
                struOPC = new structopc[strArrUnits.Length - 2];

                /* Cannot convert RedimClauseSyntax, System.InvalidCastException: Unable to cast object of type 'Microsoft.CodeAnalysis.VisualBasic.Symbols.Metadata.PE.PENamedTypeSymbolWithEmittedNamespaceName' to type 'Microsoft.CodeAnalysis.IArrayTypeSymbol'.
   at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.CreateNewArrayAssignment(ExpressionSyntax vbArrayExpression, ExpressionSyntax csArrayExpression, List`1 convertedBounds, Int32 nodeSpanStart)
   at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.VisitRedimClause(RedimClauseSyntax node)
   at Microsoft.CodeAnalysis.VisualBasic.Syntax.RedimClauseSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
   at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
   at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.ConvertWithTrivia(SyntaxNode node)
   at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.DefaultVisit(SyntaxNode node)

Input: 
oOPCCampResult(UBound(oOPCCampItems))

 */
                //oOPCCampResult[oOPCCampItems.Length];
                //Array.Resize<int>(ref oOPCCampResult, oOPCCampItems.Length);
                iParaCnt = 0;
                bool bFlag = false;

                for (iItemCnt = 0; iItemCnt < oOPCCampItems.Length; iItemCnt++)  //  for (iItemCnt = 0; iItemCnt <= Information.UBound(oOPCCampItems); iItemCnt++)
                {
                    oOPCCampResult[iItemCnt] = 0;
                    try
                    {
                        object a;
                        object b;
                        object value = oOPCCampResult[iItemCnt];
                        oOPCCampItems[iItemCnt].Read((short)OPCDotNetAutomation.OPCDataSource.OPCDevice, out value, out a, out b);

                        System.Threading.Thread.Sleep(20); // 09/08/2012 previous value 10
                    }
                    catch (Exception ex)
                    {
                        // 09/08/2012
                        iOpcReadError = iOpcReadError + 1;
                        EventViewerLog("ReadOPCValues: Read failed for item " + oOPCCampItems[iItemCnt].ItemID, "Error");
                    }

                    if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[0]) == true))
                    {
                        struOPC[iParaCnt].strBatchId = oOPCCampResult[iItemCnt].ToString();
                        bFlag = true;
                    }
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[1]) == true) & bFlag == true)
                        struOPC[iParaCnt].strRecipe = oOPCCampResult[iItemCnt].ToString().ToUpper();
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[2]) == true) & bFlag == true)
                        struOPC[iParaCnt].strFormula = oOPCCampResult[iItemCnt].ToString().ToUpper();
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[3]) == true) & bFlag == true)
                        struOPC[iParaCnt].strEquipmentTrain = oOPCCampResult[iItemCnt].ToString().ToUpper();
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[4]) == true) & bFlag == true)
                        struOPC[iParaCnt].strStartCommand = oOPCCampResult[iItemCnt].ToString().ToUpper();
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[5]) == true) & bFlag == true)
                        struOPC[iParaCnt].strStatus = oOPCCampResult[iItemCnt].ToString().ToUpper();
                    else if ((oOPCCampItems[iItemCnt].ItemID.Contains(strArrCamp[6]) == true) & bFlag == true)
                    {
                        struOPC[iParaCnt].strComplete = oOPCCampResult[iItemCnt].ToString().ToUpper();
                        bFlag = false;
                    }
                    if ((bFlag == false))
                        iParaCnt = iParaCnt + 1;
                }

                return true;
            }
            catch (Exception ex)
            {
                EventViewerLog("ReadOPCValues " + ex.Message, "Error");
                return false;
            }
            finally
            {
            }
        }
        public static bool ReadOPCValuesWatchDog()
        {

            // -------------------------------------------------------------------
            // Description: This function reads opc value for watch dog 
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            int iItemCnt;
            bool readOPCValuesWatchDog = false;
            try
            {
                if ((bOPCItemWatchDogResult == true))
                {
                    ;/* Cannot convert RedimClauseSyntax, System.InvalidCastException: Unable to cast object of type 'Microsoft.CodeAnalysis.VisualBasic.Symbols.Metadata.PE.PENamedTypeSymbolWithEmittedNamespaceName' to type 'Microsoft.CodeAnalysis.IArrayTypeSymbol'.
   at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.CreateNewArrayAssignment(ExpressionSyntax vbArrayExpression, ExpressionSyntax csArrayExpression, List`1 convertedBounds, Int32 nodeSpanStart)
   at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.VisitRedimClause(RedimClauseSyntax node)
   at Microsoft.CodeAnalysis.VisualBasic.Syntax.RedimClauseSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
   at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
   at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.ConvertWithTrivia(SyntaxNode node)
   at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.DefaultVisit(SyntaxNode node)

Input: 
oOPCWatchDogResult(UBound(oOPCWatchDogItems))

 */
                    //oOPCWatchDogResult();
                    //Array.Resize<string>(ref oOPCWatchDogResult, oOPCWatchDogItems.Length);
                    for (iItemCnt = 1; iItemCnt <= oOPCWatchDogItems.Length - 2; iItemCnt++)  //for (iItemCnt = 1; iItemCnt <= Information.UBound(oOPCWatchDogItems) - 1; iItemCnt++)
                    {
                        try
                        {
                            object a;
                            object b;
                            object value = oOPCCampResult[iItemCnt];
                            oOPCWatchDogItems[iItemCnt].Read((short)OPCDotNetAutomation.OPCDataSource.OPCDevice, out value, out a, out b);
                            System.Threading.Thread.Sleep(10);
                        }
                        catch (Exception ex)
                        {
                            readOPCValuesWatchDog = false;
                            EventViewerLog("ReadOPCValuesWatchDog: " + oOPCWatchDogItems[iItemCnt].ItemID + "  " + ex.Message, "Error");
                            return readOPCValuesWatchDog;
                        }
                    }
                    readOPCValuesWatchDog = true;
                }
            }
            catch (Exception ex)
            {
                //EventViewerLog("ReadOPCValuesWatchDog: " + oOPCWatchDogItems[iItemCnt].ItemID + "  " + ex.Message, "Error");
                readOPCValuesWatchDog = false;
            }
            return readOPCValuesWatchDog;
        }
        public static bool CheckForStartCommand(int iStructItemCnt)
        {
            // -------------------------------------------------------------------
            // Description: This function reads Start Command opc value  
            // Output: Returns True if value read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkForStartCommand = false;
            try
            {
                if ((struOPC[iStructItemCnt].strStartCommand == "1") | (struOPC[iStructItemCnt].strStartCommand.ToUpper() == "TRUE"))
                    checkForStartCommand = true;
                else
                    checkForStartCommand = false;
                if ((bDebug == true))
                    EventViewerLog("CheckForStartCommand: " + checkForStartCommand, "Message");
            }
            catch (Exception ex)
            {
                checkForStartCommand = false;
            }
            finally
            {
            }
            return checkForStartCommand;

        }
        public static bool ValidateAndCreateCampaign(int structCnt)
        {
            // -------------------------------------------------------------------
            // Description: This function reads opc value  
            // Output: Returns True if value read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool validateAndCreateCampaign = false;
            if ((bDebug == true))
                EventViewerLog("ValidateAndCreateCampaign: Declaring objects", "Message");

            DVBCTRLCAMPAIGNMGRLib.DVBCMClient objClient = new DVBCTRLCAMPAIGNMGRLib.DVBCMClient();

            object vCampa = new object();

            DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignEdit4 objCampaignEdit;


            DVBCTRLCAMPAIGNMGRLib.DVBCMExecInfo objExecInfo;
            DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3 objExecInfo3;
            // Set the Executive info object

            DVBCTRLCAMPAIGNMGRLib.DVBCMExecRecipeInfo objExecRecipeInfo;

            DVBCTRLCAMPAIGNMGRLib.DVBCMRecipeEdit objRecipeEdit;
            DVBCTRLCAMPAIGNMGRLib.DVBCMBatchEdit objBatchEdit;

            dynamic objUnitName;

            //string[] objStepName = new string[] { };
            object objStepName;
            string strMessage = "";

            try
            {
                EventViewerLog("ValidateAndCreateCampaign: Connecting to.." + strNodeName, "Message");
                try
                {
                    // Connect
                    objClient.Connect(strNodeName, false); // (My.Computer.Name, False)
                }
                catch (Exception ex)
                {
                    EventViewerLog(ex.Message, "ERROR");
                }
                if ((objClient.Connected == false))
                {
                    EventViewerLog("ValidateAndCreateCampaign: Invalid Node Name in cfg file.", "Error");
                    return false;
                }
                if ((bDebug == true))
                    EventViewerLog("ValidateAndCreateCampaign: Campaign Connect", "Message");
                try
                {
                    bool bValidCampName = false;
                    // Validate Campaign Name
                    bValidCampName = ValidateCampaignName(struOPC[structCnt].strBatchId);
                    if ((bValidCampName == false))
                    {
                        strMessage = "Invalid Campaign Name";
                        //goto LogEvent;
                        UpdateStatus(structCnt, strMessage);
                        return validateAndCreateCampaign;
                    }

                    dynamic objCampList;
                    int iCmpCnt;
                    objCampList = objClient.CampaignList;

                    DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignInfo3 objCampaignInfo;
                    DVBCTRLCAMPAIGNMGRLib.IDVBCMBatchInfo objBInfo;

                    for (iCmpCnt = 0; iCmpCnt < objCampList.Length; iCmpCnt++)   //for (iCmpCnt = 0; iCmpCnt <= Information.UBound(objCampList); iCmpCnt++)
                    {
                        if ((objCampList[iCmpCnt].ToString() == struOPC[structCnt].strBatchId))
                        {
                            //objCampaignInfo = (struOPC[structCnt].strBatchId);
                            objCampaignInfo = objClient.CampaignInfo[struOPC[structCnt].strBatchId];
                            objBInfo = objCampaignInfo.BatchInfo[struOPC[structCnt].strBatchId];

                            if ((objBInfo.State == DVBCTRLCAMPAIGNMGRLib.DVBCMBATCHSTATE.dvbcmBatchStateCompleteNoError))
                            {
                                objCampaignEdit = objClient.CampaignEdit[struOPC[structCnt].strBatchId];

                                objClient.RemoveCampaign(struOPC[structCnt].strBatchId);
                            }
                            else
                            {
                                strMessage = "Campaign Already Exist";
                                //goto LogEvent;
                                UpdateStatus(structCnt, strMessage);
                                return validateAndCreateCampaign;
                            }
                        }
                    }

                    // If campiagn name is valid create it else log it
                    objCampaignEdit = objClient.NewCampaign[struOPC[structCnt].strBatchId];

                    if ((bDebug == true))
                        EventViewerLog("ValidateAndCreateCampaign: New Campaign ", "Message");
                }
                catch (Exception ex)
                {
                    EventViewerLog(struOPC[structCnt].strBatchId + " " + ex.Message, "Error");
                    validateAndCreateCampaign = false;
                    if ((ex.Message.Contains("Campaign already exists.") == true))
                        strMessage = "Campaign Already Exist"; // 'ex.Message
                    else
                        strMessage = "Other";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }
                finally
                {
                }


                bool bSetCampAttr;
                if ((bDebug == true))
                    EventViewerLog("SetCampaignAttributes", "Message");
                // Set campaing attributes i.e. suffix="",prefix="" etc....
                bSetCampAttr = SetCampaignAttributes(ref objCampaignEdit);
                if ((bSetCampAttr == false))
                {
                    EventViewerLog("Campaign Attributes Not Set.", "Error");
                    validateAndCreateCampaign = false;
                    strMessage = "Campaign Attributes Not Set";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }
                // Upgrade V11
                // objExecInfo = objClient.ExecutiveInfo(strNodeName) '(My.Computer.Name)
                // objExecInfo3 = objClient.ExecutiveInfo(strNodeName)
                objExecInfo = objClient.ExecutiveInfo[strBExecName]; // (My.Computer.Name)
                objExecInfo3 = objClient.ExecutiveInfo[strBExecName];

                bool bCheckRecipe = false;

                // Check if Recipe Exist 
                bCheckRecipe = CheckRecipeExist(ref objExecInfo, struOPC[structCnt].strRecipe);

                if ((bCheckRecipe == false))
                {
                    EventViewerLog("Invalid Recipe: " + struOPC[structCnt].strRecipe + " for " + struOPC[structCnt].strBatchId, "Error");
                    validateAndCreateCampaign = false;
                    strMessage = "Invalid Recipe";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }

                objRecipeEdit = objCampaignEdit.RecipeEdit();
                objExecRecipeInfo = objExecInfo.ExecutiveRecipeInfo[struOPC[structCnt].strRecipe/* Conversion error: Set to default value for this argument */];

                bool bCheckEquipment = false;
                bCheckEquipment = CheckEqipmentTrainExist(struOPC[structCnt].strEquipmentTrain, struOPC[structCnt].strRecipe, ref objExecInfo3);

                // Check If Equipment Train exist
                if ((bCheckEquipment == false))
                {
                    EventViewerLog("Invalid Equipment Train: " + struOPC[structCnt].strEquipmentTrain + " for " + struOPC[structCnt].strRecipe, "Error");
                    validateAndCreateCampaign = false;
                    strMessage = "Invalid Equipment Train";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }


                DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo3 objRecipInfo3;
                DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3 objExeInfo3;
                // Upgrade V11
                // objExeInfo3 = objClient.ExecutiveInfo(strNodeName)
                objExeInfo3 = objClient.ExecutiveInfo[strBExecName];
                objRecipInfo3 = objExeInfo3.ExecutiveRecipeInfo[struOPC[structCnt].strRecipe];
                objRecipInfo3.GetEqTrainBaseClass(out strBaseClas, out strBaseClsDesc);

                // Check if Formula Exist
                bool bCheckFormula = false;
                bCheckFormula = CheckFromulaExist(ref objExecRecipeInfo, struOPC[structCnt].strFormula);

                if ((bCheckFormula == true))
                    objRecipeEdit.Formula = struOPC[structCnt].strFormula;
                else if ((struOPC[structCnt].strFormula == "" | struOPC[structCnt].strFormula == "\"\"" + "\"\""))//else if ((struOPC[structCnt].strFormula == "" | struOPC[structCnt].strFormula == Strings.Chr(34) + Strings.Chr(34)))
                    struOPC[structCnt].strFormula = "";
                else if ((bCheckFormula == false))
                {
                    EventViewerLog("Invalid Formula: " + struOPC[structCnt].strFormula + " for " + struOPC[structCnt].strRecipe, "Error");
                    validateAndCreateCampaign = false;
                    strMessage = "Invalid Formula"; // ''& struOPC(structCnt).strFormula

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }


                DVBCTRLCAMPAIGNMGRLib.IDVBCMRecipeEdit2 objRecipeEdit2;
                DVBCTRLCAMPAIGNMGRLib.IDVBCMRecipeEdit3 objRecipeEdit3;
                objRecipeEdit2 = objCampaignEdit.RecipeEdit();
                objRecipeEdit3 = objCampaignEdit.RecipeEdit();

                try
                {
                    if ((bRecipeWithoutEqTrain == false))
                        objRecipeEdit2.SetEqTrainInstance(struOPC[structCnt].strEquipmentTrain, "", strBaseClas, strBaseClsDesc);
                    else
                        bRecipeWithoutEqTrain = false;
                }
                catch (Exception ex)
                {
                    strMessage = "Other";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }
                objRecipeEdit.Name = struOPC[structCnt].strRecipe;


                objRecipeEdit.Formula = struOPC[structCnt].strFormula;
                // Upgrade V11
                // objRecipeEdit.Executive = strNodeName
                objRecipeEdit.Executive = strBExecName;
                objRecipeEdit3.Name = struOPC[structCnt].strRecipe;

                // ---------------------------------------------------
                DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo2 objExecRecipeinfo2;
                DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3 objExexInfo3;
                //object[] objBoundUnit;
                dynamic objBoundUnit;
                //bool[] objClsBase;
                object objClsBase;
                //bool[] objAliasBase;
                dynamic objAliasBase;
                string[] strUnits;
                Int32[] lgUnitIDs;
                string[] strAreaNames;
                //bool[] objOutOFservice;
                dynamic objOutOFservice;
                Int32[] iMode;
                //string[] objAreaName;
                dynamic objAreaName;
                int i;
                //Int32[] objUnitId;
                dynamic objUnitId;
                //Int32[] objAreaId;
                dynamic objAreaId;

                int length = 0;
                // Upgrade V11
                // objExexInfo3 = objClient.ExecutiveInfo(strNodeName)
                objExexInfo3 = objClient.ExecutiveInfo[strBExecName];
                objExecRecipeinfo2 = objExexInfo3.ExecutiveRecipeInfo[struOPC[structCnt].strRecipe];

                objExecRecipeinfo2.GetStepsAndBoundUnits(out objStepName, out objBoundUnit, out objClsBase, out objAliasBase, 3000);
                length = ((string[])objStepName).Length;
                strUnits = new string[length]; //Information.UBound(objStepName) + 1
                lgUnitIDs = new int[length];//Information.UBound(objStepName) + 1
                strAreaNames = new string[length]; //Information.UBound(objStepName) + 1
                iMode = new int[length]; //Information.UBound(objStepName) + 1

                for (i = 0; i < length; i++) // for (i = 0; i <= Information.UBound(objStepName); i++)
                {
                    if (objAliasBase[i] == false)
                    {
                        objExexInfo3.GetExecutiveUnitInfo2(objBoundUnit[i], out objUnitName, out objUnitId, out objOutOFservice, out objAreaName, out objAreaId);
                        strUnits[i] = objUnitName[0];

                        strAreaNames[i] = objAreaName[0];
                    }
                    else
                    {
                        strUnits[i] = objBoundUnit[i];

                        strAreaNames[i] = "Unknown";
                    }
                }

                for (i = 0; i < length; i++)  // for (i = 0; i <= Information.UBound(objStepName); i++)
                {
                    iMode[i] = 3; // From_policy
                    lgUnitIDs[i] = -999;
                }
                try
                {
                    objRecipeEdit3.SetUnitBindings_v103(objStepName, objBoundUnit, lgUnitIDs, iMode);
                }
                catch (Exception ex)
                {
                    strMessage = "Other";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }


                // ---------------------------------------------------
                // objRecipeEdit.SetUnitBindings(objStepName, objUnitName, lUnitID)
                // ---------------------------------------------------


                // Check if GID is online
                bGIDOnline = CheckGIDOnline();

                if ((bGIDOnline == false))
                {
                    EventViewerLog("GID Is Offline", "Error");
                    strMessage = "GID Is Offline";

                    //goto LogEvent;
                    UpdateStatus(structCnt, strMessage);
                    return validateAndCreateCampaign;
                }
                if ((bDeltaVStatus == true))
                {
                    try
                    {
                        objCampaignEdit.SetupComplete();
                    }
                    catch (Exception ex)
                    {
                        EventViewerLog("Create Campaign: " + ex.Message, "Error");
                        strMessage = "Other";

                        //goto LogEvent;
                        UpdateStatus(structCnt, strMessage);
                        return validateAndCreateCampaign;
                    }

                    try
                    {
                        objBatchEdit = objCampaignEdit.NewBatch[struOPC[structCnt].strBatchId];

                        objBatchEdit.SetupComplete();

                        objCampaignEdit.AddBatch(objBatchEdit, false, false);
                    }

                    catch (Exception ex)
                    {
                        EventViewerLog("Create Campaign: " + ex.Message, "Error");
                        strMessage = "Other"; // "Create Campaign: " & ex.Message

                        //goto LogEvent;
                        UpdateStatus(structCnt, strMessage);
                        return validateAndCreateCampaign;
                    }

                    if ((objClient.Connected == true))
                    {
                        try
                        {
                            // objClient.AddCampaign(objCampaignEdit, "Administrator", "deltav", "Administrator", "deltav", )
                            objClient.AddCampaign(objCampaignEdit, "", "", "", ""/* Conversion error: Set to default value for this argument */);
                            objCampaignEdit.UnLockEdit();
                            // 'objCampaignEdit.SetExecutionMode4(False, True, False)
                            objCampaignEdit.SetExecutionMode4(false, false, true);
                            objCampaignEdit.SetAutoRemove3(false, false, true, 0);
                            // For auto remove uncomment below line
                            // objCampaignEdit.SetAutoRemove3(True, True, True, 1, "", "", "", "", "")
                            // ----------------------------------
                            struOPC[structCnt].strStatus = "OK"; // "Campaign Created"
                            strMessage = "OK";
                            struOPC[structCnt].strComplete = "1";
                            strMessageCampCreated = struOPC[structCnt].strBatchId + " Campaign Created.";
                        }
                        catch (Exception ex)
                        {
                            if ((ex.Message.Contains("Campaign Already Exists") == true))
                                strMessage = "Campaign Already Exist"; // 'ex.Message
                            else
                                strMessage = "Other";
                        }
                    }

                    //LogEvent:
                    //    ;
                    //    UpdateStatus(structCnt, strMessage);
                    // struOPC(structCnt).strStatus = strMessage 'give proper message
                    // struOPC(structCnt).strComplete = "1"
                    // struOPC(structCnt).strStartCommand = "0"

                    // If (structCnt = 0) Then
                    // oOPCCampItems(4).Write(struOPC(structCnt).strStartCommand)
                    // oOPCCampItems(5).Write(struOPC(structCnt).strStatus)
                    // oOPCCampItems(6).Write(struOPC(structCnt).strComplete)
                    // Else
                    // oOPCCampItems(((((structCnt + 1) * 5) + (structCnt * 2)) - 1)).Write(struOPC(structCnt).strStartCommand)
                    // oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2)).Write(struOPC(structCnt).strStatus)
                    // oOPCCampItems(((structCnt + 1) * 5) + (structCnt * 2) + 1).Write(struOPC(structCnt).strComplete)
                    // End If
                    validateAndCreateCampaign = true;
                }
            }
            catch (Exception ex)
            {
                validateAndCreateCampaign = false;
            }

            finally
            {
                if (objClient != null)
                    objClient.Disconnect();
            }
            return validateAndCreateCampaign;
        }
        public static bool UpdateStatus(int structCnt, string strMessage)
        {

            try
            {
                struOPC[structCnt].strStatus = strMessage; // give proper message
                struOPC[structCnt].strComplete = "1";
                struOPC[structCnt].strStartCommand = "0";

                if ((structCnt == 0))
                {
                    oOPCCampItems[4].Write(struOPC[structCnt].strStartCommand);
                    oOPCCampItems[5].Write(struOPC[structCnt].strStatus);
                    oOPCCampItems[6].Write(struOPC[structCnt].strComplete);
                }
                else
                {
                    oOPCCampItems[((((structCnt + 1) * 5) + (structCnt * 2)) - 1)].Write(struOPC[structCnt].strStartCommand);
                    oOPCCampItems[((structCnt + 1) * 5) + (structCnt * 2)].Write(struOPC[structCnt].strStatus);
                    oOPCCampItems[((structCnt + 1) * 5) + (structCnt * 2) + 1].Write(struOPC[structCnt].strComplete);
                }
                return true;
            }
            catch (Exception ex)
            {
                EventViewerLog("Update Status: " + ex.Message, "Error");
                return false;
            }
        }
        public static bool SetCampaignAttributes(ref DVBCTRLCAMPAIGNMGRLib.IDVBCMCampaignEdit4 objCampaignEdit)
        {
            // -------------------------------------------------------------------
            // Description: This function sets the Campaign attributes 
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            try
            {
                objCampaignEdit.EnterSetupMode();
                objCampaignEdit.Prefix = "";
                objCampaignEdit.Suffix = "";
                objCampaignEdit.Description = "From DeltaV MES Interface";
                objCampaignEdit.MaximumActiveBatches = 1;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
            }
        }
        public static bool ValidateCampaignName(string strCampName)
        {
            // -------------------------------------------------------------------
            // Description: This function Validates Campaign name
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            try
            {
                if ((strCampName.Contains(@"\") == true) | (strCampName.Contains("/") == true) | (strCampName.Contains(":") == true) | (strCampName.Contains("*") == true) | (strCampName.Contains("?") == true) |
                    (strCampName.Contains("\"\"") == true) | (strCampName.Contains("<") == true) | (strCampName.Contains(">") == true) | (strCampName.Contains("|") == true) | (strCampName.Contains("(") == true) |
                    (strCampName.Contains(")") == true) | (strCampName.Contains(";") == true) | (strCampName.Contains("[") == true) | (strCampName.Contains("]") == true) | (strCampName.Contains(@"\") == true) |
                    (strCampName.Contains("%") == true) | (strCampName.Contains(",") == true) | (strCampName.Contains("'") == true) | (strCampName.Contains(",") == true) | (strCampName.Contains("&") == true) |
                    (strCampName.Contains(" ") == true))
                    return false;
                else
                    return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static bool CheckRecipeExist(ref DVBCTRLCAMPAIGNMGRLib.DVBCMExecInfo objExecInfo, string strRecipe)
        {
            // -------------------------------------------------------------------
            // Description: This function check if recipe is valid or not 
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkRecipeExist = false;
            try
            {
                int iCnt;
                string[] strRecipeList;
                strRecipeList = objExecInfo.ExecutiveRecipeList; // ExecutiveRecipeList();
                for (iCnt = 0; iCnt < strRecipeList.Length; iCnt++)
                {
                    if ((strRecipeList[iCnt] == strRecipe))
                    {
                        checkRecipeExist = true;
                        break;
                    }
                    else
                        checkRecipeExist = false;
                }
            }
            catch (Exception ex)
            {
                checkRecipeExist = false;
            }
            finally
            {
            }
            return checkRecipeExist;
        }

        public static bool CheckEqipmentTrainExist(string strEquipmentTrain, string strReciepName, ref DVBCTRLCAMPAIGNMGRLib.IDVBCMExecInfo3 objExeInfo3)
        {
            // -------------------------------------------------------------------
            // Description: This function check  if Equipment train is valid (find the base class name and then decide) 
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            DVBCTRLCAMPAIGNMGRLib.IDVBCMExecRecipeInfo3 objRecipInfo3;
            string strBCls;
            string strDesc;

            object strEQTrainDescCls;
            dynamic objEq;
            object objEqListDesc;
            int iCnt;

            bool checkEqipmentTrainExist = false;
            try
            {
                objRecipInfo3 = objExeInfo3.ExecutiveRecipeInfo[strReciepName];// objExeInfo3.ExecutiveRecipeInfo(strReciepName);
                objRecipInfo3.GetEqTrainBaseClass(out strBCls, out strDesc);
                if ((strBCls != ""))
                {
                    objExeInfo3.GetEqTrainList(strBCls, out strEQTrainDescCls, out objEq, out objEqListDesc);

                    if (objEq.Length > 0)
                    {
                        for (iCnt = 0; iCnt < objEq.Length; iCnt++)
                        {
                            if ((objEq[iCnt] == strEquipmentTrain))
                            {
                                checkEqipmentTrainExist = true;
                                bRecipeWithoutEqTrain = false;
                                break;
                            }
                            else
                                checkEqipmentTrainExist = false;
                        }
                    }
                }
                else if ((strBCls == "" & strReciepName != ""))
                {
                    checkEqipmentTrainExist = true;
                    bRecipeWithoutEqTrain = true;
                }
                else
                    checkEqipmentTrainExist = false;
            }
            catch (Exception ex)
            {
                checkEqipmentTrainExist = false;
            }
            finally
            {
            }
            return checkEqipmentTrainExist;
        }
        public static bool CheckFromulaExist(ref DVBCTRLCAMPAIGNMGRLib.DVBCMExecRecipeInfo objExecRecipeInfo, string strFormula)
        {
            // -------------------------------------------------------------------
            // Description: This function checks if formula is valid or not
            // Output: Returns True if values read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkFromulaExist = false;
            try
            {
                int iCnt;
                string[] strArrFormula;
                strArrFormula = objExecRecipeInfo.FormulaList();
                if ((strFormula == ""))
                {
                    checkFromulaExist = true;
                    return checkFromulaExist;
                }
                if ((strArrFormula.Length == 0))
                {
                    checkFromulaExist = true;
                    return checkFromulaExist;
                }

                for (iCnt = 0; iCnt < strArrFormula.Length; iCnt++)  //for (iCnt = 0; iCnt <= Information.UBound(strArrFormula); iCnt++)
                {
                    if ((strArrFormula[iCnt] == strFormula))
                    {
                        checkFromulaExist = true;
                        break;
                    }
                    else
                        checkFromulaExist = false;
                }
            }
            catch (Exception ex)
            {
                checkFromulaExist = false;
            }
            finally
            {
            }
            return checkFromulaExist;
        }
        public static bool CheckGIDOnline()
        {
            // -------------------------------------------------------------------
            // Description: This function check is GID is online or not
            // Output: Returns True if value read successfully
            // Returns False if not
            // -------------------------------------------------------------------
            bool checkGIDOnline = false;
            try
            {
                if ((oOPCWatchDogResult[2] == "0"))
                {
                    bGIDOnline = true;
                    checkGIDOnline = true;
                }
                else
                    checkGIDOnline = false;
            }
            catch (Exception ex)
            {
                checkGIDOnline = false;
            }
            finally
            {
            }
            return checkGIDOnline;
        }

        public static bool EventViewerLog(string strSource, string strType)
        {
            // -------------------------------------------------------------------
            // Description :This function writes the message to the event viewer
            // Output: Returns True if message logged successfully
            // Returns False if not
            // -------------------------------------------------------------------
            try
            {
                if ((strSource == ""))
                    return false;
                string logError = "Application";
                if ((!(System.Diagnostics.EventLog.SourceExists("DeltaVMESInterfaceService"))))
                    System.Diagnostics.EventLog.CreateEventSource("DeltaVMESInterfaceService", logError);
                if ((strType).ToUpper() == "ERROR")
                    System.Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Error);
                else if ((strType).ToUpper() == "MESSAGE")
                    System.Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Information);
                else
                    System.Diagnostics.EventLog.WriteEntry("DeltaVMESInterfaceService", strSource, EventLogEntryType.Warning);
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {

            }
            return true;
        }
        public static void WatchDogThread()
        {
            // -------------------------------------------------------------------
            // Description :This function will be a thread called every 10 seconds 
            // Output:Returns True if thread executed successfully
            // Returns False if not
            // -------------------------------------------------------------------
            DateTime OldTime;
            clsOPC cOPCWatchDog = new clsOPC();
            try
            {
                // Check if FRSOPCDV.exe is running or not
                //FRSOPCDV:
                //    ;
                //    bFrsopcdv = CheckFRSOPCDV();

                //    if ((bFrsopcdv == false))
                //    {
                //        System.Threading.Thread.Sleep(60000);
                //        goto FRSOPCDV;
                //    }
                FRSOPCDV();
                if ((bDebug == true))
                    EventViewerLog("CheckFRSOPCDV Completed", "Message");

                try
                {
                    if ((iStartWatchCnt == 0))
                    {
                        // Connect to OPC server and add Gropp to it
                        bOPCItemWatchDogResult = cOPCWatchDog.Start_OPC(ref oOPCServerWD, ref oOPCWatchDogControlGroup, ref oOPCWatchDogItems, strArrWatchDog, "DVWatchDog");

                        iStartWatchCnt = 1;
                    }
                }
                catch (Exception ex)
                {
                    EventViewerLog("Start OPC: WatchDog Thread " + ex.Message, "Error");

                    return;
                }
                OldTime = DateTime.Now;
                while (bterminate == false & iStartWatchCnt == 1)
                {
                    try
                    {
                        //if (DateTime.DateDiff(DateInterval.Second, OldTime, DateTime.Now) > 10)
                        if ((DateTime.Now - OldTime).TotalSeconds > 10)
                        {
                            bool bWriteWDI;

                            bWriteWDI = WriteWatchDogInterface();
                            if ((bWriteWDI == true))
                            {
                                bool bReadWatchDogDeltaV;

                                bReadWatchDogDeltaV = ReadWatchDogDeltaV();
                                if ((bReadWatchDogDeltaV == true))
                                {
                                    if ((bDVPrev != bDeltaVStatus))
                                    {
                                        if ((bDeltaVStatus == true))
                                            EventViewerLog("DeltaV is Online.", "Message");
                                        else
                                            EventViewerLog("DeltaV is Offline.", "Error");
                                    }
                                }
                            }
                            OldTime = DateTime.Now;
                        }
                    }
                    catch (Exception ex)
                    {
                        EventViewerLog("WatchDogThread: " + ex.Message, "Error");
                    }
                    System.Threading.Thread.Sleep(10000);
                }
            }
            catch (Exception ex)
            {
                EventViewerLog("WatchDogThread: " + ex.Message, "Error");
            }
            finally
            {
                // 21/08/2012
                if (oOPCServerWD != null)
                    oOPCServerWD.Disconnect();
            }
        }

        public static bool WriteWatchDogInterface()
        {
            // -------------------------------------------------------------------
            // Description :This function will set the Watch Dog Interface parameter
            // Output:Returns True if thread executed successfully
            // Returns False if not
            // -------------------------------------------------------------------

            int iCnt = 0;
            bool writeWatchDogInterface = false;
            try
            {
                for (iCnt = 0; iCnt <= oOPCWatchDogItems.Length - 2; iCnt++)   //for (iCnt = 0; iCnt <= Information.UBound(oOPCWatchDogItems) - 1; iCnt++)
                {
                    if ((oOPCWatchDogItems[iCnt].ItemID.Contains("/WATCHDOG_INTERFA.CV") == true))
                    {
                        oOPCWatchDogItems[iCnt].Write("1");
                        System.Threading.Thread.Sleep(10);
                        writeWatchDogInterface = true;

                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                EventViewerLog("WriteWatchDogInterface: " + oOPCWatchDogItems[iCnt].ItemID, "Error");
                writeWatchDogInterface = false;
            }
            finally
            {
            }
            return writeWatchDogInterface;
        }
        public static bool ReadWatchDogDeltaV()
        {
            // -------------------------------------------------------------------
            // Description :This function will read the Watch Dog DeltaV parameter
            // Output:Returns True if thread executed successfully
            // Returns False if not
            // -------------------------------------------------------------------

            string strValue;
            bool bReadValue;
            bool readWatchDogDeltaV;
            try
            {
                // Read OPC values for Watch dog.
                bReadValue = ReadOPCValuesWatchDog();
                if ((bReadResult == false))
                {
                    readWatchDogDeltaV = false;
                    EventViewerLog("ReadWatchDogDeltaV: Read DeltaV Watch Dog Failed. ", "Error");
                    return readWatchDogDeltaV;
                }
                strValue = oOPCWatchDogResult[1]; // Check if WATCHDOGS/WATCHDOG_DELTAV.CV is 1
                if ((strValue == "1"))
                {
                    oOPCWatchDogItems[1].Write("0");
                    bDVPrev = bDeltaVStatus;
                    bDeltaVStatus = true;
                }
                else
                {
                    bDVPrev = bDeltaVStatus;
                    bDeltaVStatus = false;
                }
                readWatchDogDeltaV = true;
            }
            catch (Exception ex)
            {
                readWatchDogDeltaV = false;
                EventViewerLog("ReadWatchDogDeltaV: Read DeltaV Watch Dog Failed. ", "Error");
            }
            finally
            {
            }
            return readWatchDogDeltaV;
        }
        private static void CheckFrsop()
        {
            if ((bFrsopcdv == false))
            {
                System.Threading.Thread.Sleep(60000);
                CheckFrsop();
            }
        }

        private static void FRSOPCDV()
        {
            if ((bFrsopcdv == false))
            {
                System.Threading.Thread.Sleep(60000);
                FRSOPCDV();
            }
        }
        private static void CampMgr()
        {
            bCampMgr = CheckCampMagr();

            if ((bCampMgr == false))
            {
                EventViewerLog("DeltaVMESInterface Waiting for DeltaV Campaign Manager Service to start...", "Warning");
                System.Threading.Thread.Sleep(60000);
                CampMgr();
            }
        } 

        private static void CheckFrsop2()
        {
            if ((bFrsopcdv == false))
            {
                System.Threading.Thread.Sleep(60000);
                CheckFrsop2();
            }
        }
    }
}




