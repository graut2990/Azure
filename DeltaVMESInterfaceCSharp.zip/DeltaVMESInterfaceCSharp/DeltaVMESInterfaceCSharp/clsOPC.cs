﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Globalization;
//using System.IO;
//using System.Linq;
//using System.Reflection;
//using System.Runtime.CompilerServices;
//using System.Security;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.VisualBasic;
//namespace DeltaVMESInterface
//{

//}


using System;
using OPCDotNetAutomation;

namespace DeltaVMESInterfaceCSharp
{
    public class clsOPC
    {
        public const string g_OPCServer = "OPC.DeltaV.1"; // OPC Server Name
                                                          // ================================================================================
                                                          // Description       :Function Start OPC (Connect opc,Addd Group to server,Add items to Group)
                                                          // Input Parameters  :OPC Item array,Tag array
                                                          // Output Parameters :True if Folders Created sucessfully,False if failed to create
                                                          // ================================================================================
        private bool Start_OPC_Result = false;
        public bool Start_OPC(ref OPCDotNetAutomation.OPCServer oOPCServer, ref OPCDotNetAutomation.OPCGroup oOPCControlGroup, ref OPCDotNetAutomation.OPCItem[] oOPCItem, string[] sTag, string strOPCGrpName)
        {
            
            try
            {
                short iTag;


                Start_OPC_Result = false;
                // ---------------------------------------------------------
                // Find and connect to the OPC Server
                // ---------------------------------------------------------
                try
                {
                    if ((oOPCServer == null))
                    {
                        oOPCServer = new OPCDotNetAutomation.OPCServer();
                        oOPCServer.Connect(g_OPCServer,modDVMES.strNodeName);
                    }
                }
                catch (Exception ex)
                {
                    oOPCServer = null/* TODO Change to default(_) if this is not a reference type */;
                    Start_OPC_Result = false;
                    modDVMES.EventViewerLog("Invalid Node Name in cfg file", "Error");

                    return Start_OPC_Result;
                }
                System.Threading.Thread.Sleep(1000);
                // ---------------------------------------------------------
                // Create a "Control" group 
                // ---------------------------------------------------------

                try
                {
                    if ((oOPCControlGroup == null))
                    {
                        try
                        {
                            oOPCControlGroup = oOPCServer.OPCGroups.Add(strOPCGrpName);
                            oOPCControlGroup.UpdateRate = 1000;
                            oOPCControlGroup.IsActive = true;
                        }
                        catch (Exception ex)
                        {
                            modDVMES.EventViewerLog("Start OPC: Creating OPC Group " + strOPCGrpName, "Error");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Start_OPC_Result = false;

                    modDVMES.EventViewerLog("Invalid Node Name in cfg file", "Error");
                }
                // ---------------------------------------------------------
                // Add item to group
                // ---------------------------------------------------------
                oOPCItem = new OPCDotNetAutomation.OPCItem[sTag.Length];  //Information.UBound(sTag) + 1
                try
                {
                    for (iTag = 0; iTag < sTag.Length; iTag++)
                    {
                        if ((sTag[iTag] != null) | (sTag[iTag] != ""))
                        {
                            try
                            {
                                oOPCItem[iTag] = oOPCControlGroup.OPCItems.AddItem(sTag[iTag].Trim(), oOPCControlGroup.ClientHandle);
                                System.Threading.Thread.Sleep(20);
                            }
                            catch (Exception ex)
                            {
                                Start_OPC_Result = false;
                                modDVMES.EventViewerLog("Start OPC: " + ex.Message, "Error");
                            }
                        }
                    }

                    Start_OPC_Result = true;
                    return Start_OPC_Result;
                }
                catch (Exception ex)
                {
                    modDVMES.EventViewerLog("Start OPC: " + ex.Message, "Error");
                }
            }
            catch (Exception ex)
            {
                //break;
                modDVMES.EventViewerLog(strOPCGrpName + " : " + ex.Message, "Error");
                Start_OPC_Result = false;
            }
            finally
            {
            }
            return Start_OPC_Result;
        }
    }



}

