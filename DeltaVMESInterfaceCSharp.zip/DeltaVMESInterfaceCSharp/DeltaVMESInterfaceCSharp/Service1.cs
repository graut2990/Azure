﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DeltaVMESInterfaceCSharp
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
          //  Thread.Sleep(25000);


            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') + ".txt";

            if (!File.Exists(filepath))
            {
                // Create a file to write to.  

                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine("service started");
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine("service started");

                }

            }


            //if (Debug.AutoFlush)
            //Debugger.Launch();
//#endif

            // Set thread priority
            modDVMES.thCampaign.Priority = System.Threading.ThreadPriority.BelowNormal;
            modDVMES.thWatchDog.Priority = System.Threading.ThreadPriority.BelowNormal;

            // --------------------------------------------------
            // Setting the global boolean variable to false
            // to start the while loop of thread
            modDVMES.bterminate = false;
            // --------------------------------------------------

            // Get version number of the application to log it in Event viewer
            string strVersion;
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            
            //strVersion = My.Application.Info.Version.Major + "." + My.Application.Info.Version.Minor + "." + My.Application.Info.Version.Build;
            strVersion = fvi.FileVersion;
            modDVMES.EventViewerLog("DeltaVMESInterfaceCSharp Service " + strVersion + " Starting...", "Message");

            // Read TagConfiguration file
            modDVMES.bReadResult = modDVMES.ReadTagConfigurationFile();

            // Logg in Event viewer only if Debug is set to 1 in cfg file
            if ((modDVMES.bDebug == true))
                modDVMES.EventViewerLog("Read Tag Conifguration Complete", "Message");


            if ((modDVMES.bReadResult == false))
            {
                modDVMES.EventViewerLog("ReadTagConfigurationFile: Read Tag Configuration Failed.", "Error");
                return;
            }

            if ((modDVMES.bDebug == true))
                modDVMES.EventViewerLog("CreateTagList Started", "Message");

            // Call Create Tag List to create respective tags for each unit read from the config file
            modDVMES.bCreateTagList = modDVMES.CreateTagList();

            if ((modDVMES.bDebug == true))
                modDVMES.EventViewerLog("CreateTagList complete", "Message");

            if ((modDVMES.bCreateTagList == false))
            {
                modDVMES.EventViewerLog("CreateTagList: Create Tag List Failed.", "Error");
                return;
            }

            if ((modDVMES.bDebug == true))
                modDVMES.EventViewerLog("thWatchDog Starting", "Message");

            // Start Watch Dog thread 
            modDVMES.thWatchDog.Start();
            System.Threading.Thread.Sleep(1000);
            if ((modDVMES.bDebug == true))
                modDVMES.EventViewerLog("thCampaign Starting", "Message");

            // Start Campaign thread 
            modDVMES.thCampaign.Start();
        }


        protected override void OnStop()
        {
            // Add code here to perform any tear-down necessary to stop your service.
            // --------------------------------------------------
            // Setting the global boolean variable to true to
            // terminate the while loop of the threads
            modDVMES.bterminate = true;
            // --------------------------------------------------
            if (!(modDVMES.thCampaign == null))
            {
                //while (modDVMES.thCampaign.ThreadState != System.Threading.ThreadState.Stopped)
                //{
                //}
            }
            if (!(modDVMES.thWatchDog == null))
            {
                //while (modDVMES.thWatchDog.ThreadState != System.Threading.ThreadState.Stopped)
                //{                    
                //}
            }
        } 

        

    }
}
