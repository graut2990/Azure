﻿function validateToDoItemTimestamp() {

    var context = getContext();
    var request = context.getRequest();
    // context.getResponse();   In Post Trigger all things are same.

    var itemToCreate = request.getBody();

    if (!("timestamp" in itemToCreate)) {
        var ts = new Date();
        itemToCreate["timestamp"] = ts.getTime();
    }

    request.setBody(itemToCreate);
}