﻿function testsp(item) {
    var context = getContext();
    var container = context.getCollection();

    var accepted = container.createDocument(container.getSelfLink(),
        item,
        function (err, item) {
        if (err) throw new Error("Error: " + err.message)
        context.getResponse().setBody(item.id)

    })
    if (!accepted) return
}