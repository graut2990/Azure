﻿//Bounded execution within stored procedures

//The following is an example of a stored procedure that bulk - imports items into an Azure Cosmos container.The stored procedure handles bounded execution by checking
//the boolean return value from createDocument, and then uses the count of items inserted in each invocation of the stored procedure to track and resume progress across batches.

function bulkImport(items) {

    var context = getContext();
    var container = context.getCollection();

    if (!items)
        throw new Error("The array is undefined or null.");
    
    var itemsLength = items.length;

    if (itemsLength == 0) {
        getContext().getResponse().setBody(0);
    }

    var count = 0;

    tryCreate(items[0], callback)


    function tryCreate(item, callback) {
        var isAccepted  = container.createDocuments(container.getSelfLink(), item, callback)

        if (!isAccepted) getContext().getResponse().setBody(count);

    }

    function callback(err, item, options) {
        if (err) throw err;

        count++;

        if (count >= itemsLength) {
            etContext().getResponse().setBody(count);
        } else {
            tryCreate(items[count],callback)
        }
    }
}