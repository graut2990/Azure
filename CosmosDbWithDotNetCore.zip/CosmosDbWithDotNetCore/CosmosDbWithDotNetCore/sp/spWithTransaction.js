﻿//Transactions within stored procedures

//You can implement transactions on items within a container by using a stored procedure.The following example uses transactions within a fantasy football gaming app
//to trade players between two teams in a single operation.The stored procedure attempts to read the two Azure Cosmos DB items each corresponding to the player IDs passed
//in as an argument.If both players are found, then the stored procedure updates the items by swapping their teams.If any errors are encountered along the way,
//the stored procedure throws a JavaScript exception that implicitly aborts the transaction.

function spWithTransaction(familyId1, familyId2) {

    var context = getContext();
    var container = context.getCollection();
    var response = context.getResponse();

    var family1Document, family2Document;

    var filterQuery =
    {
        'query': 'Select * from FamilyCollection_oa p where p.id = @familyId1',
        'parameters': [{ 'name': '@familyId1', 'value': familyId1}]
    }

    var accept = container.queryDocuments(container.getSelfLink(), filterQuery, {},
        function (err, items, responeOption) {
            if (err) throw new Error("Error: " + err.message)

            if (items.length != 1)
                throw "unable to find both families"

            family1Document = items[0];

            var filterQuery2 =
            {
                'query': 'Select * from FamilyCollection_oa p where p.id = @familyId2',
                'parameters': [{ 'name': '@familyId2', 'value': familyId2}]
            }

            var accept2 = container.queryDocuments(container.getSelfLink(), filterQuery2, {},
                function (err2, items2, responseOption2) {
                    if (err2) throw new Error("Error: " + err.message)

                    if (items2.length != 1)
                        throw "unable to find both families"

                    family2Document = items[0]
                    swapFamiliesLastName(family1Document, family2Document)
                    return
                })

            if (!accept2) throw "Unable to read player details, abort ";
        })

    if (!accept) throw "Unable to read player details, abort ";

    function swapFamiliesLastName(family1, family2) {
        var family2NewLastName = family1.LastName;
        family1.LastName = family2.team;
        family2.LastName = family2NewLastName;

        var accept = container.replaceDocument(family1._self, family1,
            function (err, itemReplaced) {
                if (err) throw "Unable to update family 1 Last Name, abort ";

                var accept2 = container.replaceDocument(family2._self, family2,
                    function (err2, itemReplaced2) {
                        if (err2) throw "Unable to update family 2 Last Name, abort ";
                })

                if (!accept2) throw "Unable to update family 2 Last Name, abort ";
            })
        if (!accept) throw "Unable to update family 1 Last Name, abort ";
    }
}


