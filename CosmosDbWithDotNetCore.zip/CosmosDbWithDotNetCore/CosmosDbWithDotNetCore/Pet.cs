﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosDbWithDotNetCore
{
    public class Pet
    {
        public string GivenName { get; set; }
    }   
}
