﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosDbWithDotNetCore
{
    public class Parent
    {
        public string FamilyName { get; set; }
        public string FirstName { get; set; }
    }
}
