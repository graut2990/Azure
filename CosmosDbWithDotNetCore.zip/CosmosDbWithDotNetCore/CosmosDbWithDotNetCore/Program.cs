﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CosmosDbWithDotNetCore
{
    class Program
    {
        private const string databaseId = "traildoc1db";
        private const string connectionPolicy = ""; //ConfigurationManager.AppSettings["EndPointUrl"];
        private const string authorizationKey = "eZCc0Gq9guq6ws5HUz1l5OZ7LymVFhsYL0ur8M6TJXFUIF7fhggT114X9WBaR1Ac6LOW38yNx1AJQ89iAd8kqg==";
        private const string endpointUrl = "https://trialdocdb.documents.azure.com:443/";

        private static DocumentClient client;

        public Program()
        {
            client = new DocumentClient(new Uri(endpointUrl), authorizationKey);
        }
        static void Main(string[] args)
        {
            try
            {
                Program p = new Program();
                //p.CreateDataBase().Wait();
                //p.CreateCollection().Wait();
                //p.CreateTrigger().Wait();
                //p.CreateDocument().Wait();
                p.ReadDocument();
                //p.UpdateDocument();
                //p.CreateStoreprocedure().Wait();
                //p.ExecuteStoreProcedure().Wait();
                //p.DeleteCollection();
                //p.DeleteDatabase().Wait();               
                //p.ExecuteTrigger().Wait();
            }
            catch (DocumentClientException de)
            {
                Exception baseException = de.GetBaseException();
                Console.WriteLine("{0} error occurred: {1}, Message: {2}", de.StatusCode, de.Message, baseException.Message);
            }
            catch (Exception e)
            {
                Exception baseException = e.GetBaseException();
                Console.WriteLine("Error: {0}, Message: {1}", e.Message, baseException.Message);
            }
            finally
            {
                Console.WriteLine("End of demo, press any key to exit.");
                Console.ReadKey();
            }

        }

        #region Database
        /// <summary>
        /// Create Database
        /// </summary>
        /// <returns></returns>
        private async Task CreateDataBase()
        {          
             // 1 -  Query for a Database
             //Database database1 = client.CreateDatabaseQuery().Where(db => db.Id == databaseId).AsEnumerable().FirstOrDefault();
             //Console.WriteLine("1. Query for a database returned: {0}", database1 == null ? "no results" : database1.Id.ToString());

             // 2 -  Create a Database
             var database = client.CreateDatabaseIfNotExistsAsync(new Database { Id = databaseId });
             Console.WriteLine("2. Query for a database returned: {0}", database == null ? "no results" : database.Id.ToString());

             //var database2 = client.CreateDatabaseAsync(new Database { Id = databaseId }, new RequestOptions { OfferThroughput = 1000 });
             //Console.WriteLine("3. Query for a database returned: {0}", database2 == null ? "no results" : database2.Id.ToString());

             //// 3 - Get a single database
             //var database4 = client.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(databaseId));
             //Console.WriteLine("\n3. Read a database resource: {0}", database4);

             // 4 - List all databases for an account
             var databases = await client.ReadDatabaseFeedAsync();
             Console.WriteLine("\n4. Reading all databases resources for an account");
             foreach (var db in databases)
             {
                 Console.WriteLine(db);
             }

        }

        /// <summary>
        /// Delete Database
        /// </summary>
        /// <returns></returns>
        private async Task DeleteDatabase()
        {
            await client.DeleteDatabaseAsync(UriFactory.CreateDatabaseUri(databaseId));
            Console.WriteLine("\n Database deleted");
        }

        #endregion

        #region Collection 

        /// <summary>
        /// Create Collection
        /// </summary>
        /// <returns></returns>
        private async Task CreateCollection()
        {
            // client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(databaseId),new SqlQuerySpec { QueryText="",Parameters = new SqlParameterCollection { } });

            await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(databaseId), new DocumentCollection { Id = "FamilyCollection_oa" });

            //await client.CreateDocumentCollectionAsync(UriFactory.CreateDatabaseUri(databaseId), new DocumentCollection { Id = "FamilyCollection_oa" });
        }

        /// <summary>
        /// Delete Collection
        /// </summary>
        private void DeleteCollection()
        {
            client.DeleteDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"));
            Console.WriteLine("\n Collection deleted");
        }

        #endregion
        
        #region Document


        /// <summary>
        /// Create Document
        /// </summary>
        /// <returns></returns>
        private async Task CreateDocument()
        {

            Family taylorFamily = new Family
            {
                Id = "taylor.1",
                LastName = "taylor",
                Parents = new Parent[]
        {
                new Parent { FirstName = "Ross" },
                new Parent { FirstName = "Jenny Kay" }
        },
                Children = new Child[]
        {
                new Child
                {
                        FirstName = "Helina taylor",
                        Gender = "female",
                        Grade = 5,
                        Pets = new Pet[]
                        {
                                new Pet { GivenName = "Fluffy" }
                        }
                }
        },
                Address = new Address { State = "WA", County = "King", City = "Seattle" },
                IsRegistered = true
            };

            RequestOptions requestOptions = new RequestOptions
            {
                PreTriggerInclude = new List<string> { "preTrigger" }
            };

               await   client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), taylorFamily, requestOptions);

            //    Family andersenFamily = new Family
            //    {
            //        Id = "Andersen.1",
            //        LastName = "Andersen",
            //        Parents = new Parent[]
            //{
            //        new Parent { FirstName = "Thomas" },
            //        new Parent { FirstName = "Mary Kay" }
            //},
            //        Children = new Child[]
            //{
            //        new Child
            //        {
            //                FirstName = "Henriette Thaulow",
            //                Gender = "female",
            //                Grade = 5,
            //                Pets = new Pet[]
            //                {
            //                        new Pet { GivenName = "Fluffy" }
            //                }
            //        }
            //},
            //        Address = new Address { State = "WA", County = "King", City = "Seattle" },
            //        IsRegistered = true
            //    };
            //   await   client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), andersenFamily);
            //    Family wakefieldFamily = new Family
            //    {
            //        Id = "Wakefield.7",
            //        LastName = "Wakefield",
            //        Parents = new Parent[]
            //{
            //        new Parent { FamilyName = "Wakefield", FirstName = "Robin" },
            //        new Parent { FamilyName = "Miller", FirstName = "Ben" }
            //},
            //        Children = new Child[]
            //{
            //        new Child
            //        {
            //                FamilyName = "Merriam",
            //                FirstName = "Jesse",
            //                Gender = "female",
            //                Grade = 8,
            //                Pets = new Pet[]
            //                {
            //                        new Pet { GivenName = "Goofy" },
            //                        new Pet { GivenName = "Shadow" }
            //                }
            //        },
            //        new Child
            //        {
            //                FamilyName = "Miller",
            //                FirstName = "Lisa",
            //                Gender = "female",
            //                Grade = 1
            //        }
            //},
            //        Address = new Address { State = "NY", County = "Manhattan", City = "NY" },
            //        IsRegistered = false
            //    };
            //    await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), wakefieldFamily);
        }

        /// <summary>
        /// Read document
        /// </summary>
        private void ReadDocument()
        {
           var data =  client.CreateDocumentQuery<Family>(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), new FeedOptions { MaxItemCount = -1 });
            foreach (Family family in data)
            {
                Console.WriteLine("\tRead {0}", family);
            }          

            var WakefieldDataQuery = client.CreateDocumentQuery<Family>(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), "SELECT * FROM Family WHERE Family.LastName = 'Wakefield'", new FeedOptions { MaxItemCount = -1 });//.Where(f => f.LastName == "Wakefield");

            foreach (Family family in WakefieldDataQuery)
            {
                Console.WriteLine(("\n  {0}", family));
            }
            
        }

        /// <summary>
        /// Update Document
        /// </summary>
        private void UpdateDocument()
        {
            Family updateFamily = new Family
            {
                Id = "Andersen.1",
                LastName = "Andersen",
                Parents = new Parent[]
      {
                new Parent { FirstName = "Thomas1" },
                new Parent { FirstName = "Mary Kay1" }
      },
                Children = new Child[]
      {
                new Child
                {
                        FirstName = "Henriette Thaulow1",
                        Gender = "female",
                        Grade = 5,
                        Pets = new Pet[]
                        {
                                new Pet { GivenName = "Fluff1y" }
                        }
                }
      },
                Address = new Address { State = "WA1", County = "Kin1g", City = "Seattle1" },
                IsRegistered = false
            };

            client.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(databaseId, "FamilyCollection_oa", "Andersen.1"), updateFamily);

            var UpdatedAndersenQuery = client.CreateDocumentQuery<Family>(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), new FeedOptions { MaxItemCount = -1 }).Where(f => f.LastName == "Andersen");
            foreach (Family family in UpdatedAndersenQuery)
            {
                Console.WriteLine(("\n Update Details \n {0}", family));
            }
        }

        /// <summary>
        /// Delete Document
        /// </summary>
        private void DeleteDocument()
        {      
            client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(databaseId, "FamilyCollection_oa", "Andersen.1"));

            Console.WriteLine(("\n Document Deleted."));
        }

        #endregion

        #region Store Procedure

        private async Task CreateStoreprocedure()
        {
            var spBody = File.ReadAllText(@"D:\Gaurav\Project\CosmosDbWithDotNetCore\CosmosDbWithDotNetCore\sp\addItemInCollection.js");
            var spDefination = new StoredProcedure { Id = "addItemInCollection", Body = spBody };

            StoredProcedure sproc = await client.CreateStoredProcedureAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), spDefination);
            Console.WriteLine($"\r\nCreated Store procedure Id:{sproc.Id} ");
        }

        private async Task ExecuteStoreProcedure()
        {
            Family hassyFamily = new Family
            {
                Id = "Hassy.1",
                LastName = "Hassy",
                Parents = new Parent[]
        {
                new Parent { FirstName = "Michel" },
                new Parent { FirstName = "Mary Kay" }
        },
                Children = new Child[]
        {
                new Child
                {
                        FirstName = "Jason Roy",
                        Gender = "male",
                        Grade = 5,
                        Pets = new Pet[]
                        {
                                new Pet { GivenName = "Fluffy" }
                        }
                }
        },
                Address = new Address { State = "WA", County = "King", City = "Seattle" },
                IsRegistered = true
            };
            var result =await client.ExecuteStoredProcedureAsync<string>(UriFactory.CreateStoredProcedureUri(databaseId, "FamilyCollection_oa", "addItemInCollection"), hassyFamily);

            Console.WriteLine($"Executed Store Procedure: response:{result.Response}");
            Console.WriteLine("reading the document collection after adding new document in collection");
            ReadDocument();
        }

        #endregion

        #region Trigger

        private async Task CreateTrigger()
        {
            Trigger trigger = new Trigger
            {
                Id = "preTrigger",
                Body = File.ReadAllText(@"D:\Gaurav\Project\CosmosDbWithDotNetCore\CosmosDbWithDotNetCore\trigger\preTrigger.js"),
                TriggerOperation = TriggerOperation.Create,
                TriggerType = TriggerType.Pre  // type can be PRE or POST
          };

            await client.CreateTriggerAsync(UriFactory.CreateDocumentCollectionUri(databaseId, "FamilyCollection_oa"), trigger);
        }

        private async Task ExecuteTrigger()
        {
            Family taylorFamily = new Family
            {
                Id = "taylor.1",
                LastName = "taylor",
                Parents = new Parent[]
        {
                new Parent { FirstName = "Ross" },
                new Parent { FirstName = "Jenny Kay" }
        },
                Children = new Child[]
        {
                new Child
                {
                        FirstName = "Helina taylor",
                        Gender = "female",
                        Grade = 5,
                        Pets = new Pet[]
                        {
                                new Pet { GivenName = "Fluffy" }
                        }
                }
        },
                Address = new Address { State = "WA", County = "King", City = "Seattle" },
                IsRegistered = true
            };

            RequestOptions requestOptions = new RequestOptions
            {
                PreTriggerInclude = new List<string> { "preTrigger" }
            };
            var result = await client.ExecuteStoredProcedureAsync<string>(UriFactory.CreateStoredProcedureUri(databaseId, "FamilyCollection_oa", "addItemInCollection"), requestOptions, taylorFamily);

            Console.WriteLine($"Executed Store Procedure: response:{result.Response}");
            Console.WriteLine("reading the document collection after adding new document in collection");
            ReadDocument();
        }

        #endregion

        #region UDF

        private async Task CreateUDF()
        {
            string udfId = "Tax";
            var udfTax = new UserDefinedFunction
            {
                Id = udfId,
                Body = File.ReadAllText(@"D:\Gaurav\Project\CosmosDbWithDotNetCore\CosmosDbWithDotNetCore\udf\Tax.js"),
            };

            Uri containerUri = UriFactory.CreateDocumentCollectionUri("myDatabase", "myContainer");
            await client.CreateUserDefinedFunctionAsync(containerUri, udfTax);

        }

        private void ExecuteUDF()
        {
            Uri containerUri = UriFactory.CreateDocumentCollectionUri("myDatabase", "myContainer");
            var results = client.CreateDocumentQuery<dynamic>(containerUri, "SELECT * FROM Incomes t WHERE udf.Tax(t.income) > 20000");
        }

        #endregion
    }
}
