﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosDbWithDotNetCore
{
    public class Address
    {
        public string State { get; set; }
        public string County { get; set; }
        public string City { get; set; }
    }
}
