﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Specialized;
using System.Net;
using System.Web;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Queue;
using Microsoft.Extensions.Configuration;

namespace ApiAppAsConnectorForLogicApp.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        //static CloudBlobClient cloudBlobClient;
        //const string blobContainerName = "active-lists";
        //static CloudBlobContainer cloudBlobContainer;

        static CloudQueueClient cloudQueueClient;
        static CloudQueue cloudQueue;
        static CloudQueueMessage cloudQueuemessage;

        // CloudConfigurationManager.GetSetting("StorageConnectionString"));
        IConfiguration _configuration;
        IResponseFormatService _responseFormatService;
        /// <summary>
        /// Constrctor of controller intialize the depedency
        /// </summary>
        /// <param name="responseFormatService"></param>
        public MessageController(IResponseFormatService responseFormatService, IConfiguration configuration)
        {
            _responseFormatService = responseFormatService;
            _configuration = configuration;
        }


        /// <summary>
        /// Send text message using get request
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult SendMessage_Get(string number)
        {
            dynamic json = string.Empty;
            string status = string.Empty;
            try
            {
                String message = HttpUtility.UrlEncode("This is my first meesage");
                using (var wb = new WebClient())
                {
                    byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "DokDAAFOv8g-M0O2GKruhLKi1iQFm5yNevPMD4ty0P"},
                {"numbers" , $"91{number}"},
                {"message" , message},
                {"sender" , "test"} ///TXTLCL
                });
                    string result = System.Text.Encoding.UTF8.GetString(response);
                    json = JsonConvert.DeserializeObject(result);

                    status = json.status;
                    if (json.status == "success")
                        return Ok(_responseFormatService.SetResponse(status, (string)json.balancejson, json.messages,true,string.Empty));
                    else
                        return Ok(_responseFormatService.SetResponse(status, string.Empty, json.errors,true,string.Empty));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(_responseFormatService.SetResponse(status, string.Empty, ex.Message,true,string.Empty));
            }
        }
      
        /// <summary>
        /// Tested api is working or not
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public string TestApi()
        {
            return "Api is in working state";
        }

        /// <summary>
        /// Send text message using post request
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IActionResult SendMessage([FromBody] Model model)
        {
            //string number = HttpContext.Request.Form["number"];
            dynamic json = string.Empty;
            string status = string.Empty;
            try
            {
                if (model is null || string.IsNullOrEmpty(model.Number))
                    return Ok(new { status = "failure", result = "Recipient number is required" });

                string message = HttpUtility.UrlEncode("This is my first meesage");
                using (var wb = new WebClient())
                {
                    byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "DokDAAFOv8g-M0O2GKruhLKi1iQFm5yNevPMD4ty0P"},
                {"numbers" , $"91{model.Number}"},
                {"message" , message},
                {"sender" , "test"}  //
                });
                    string result = System.Text.Encoding.UTF8.GetString(response);
                    json = JsonConvert.DeserializeObject(result);

                    status = json.status;

                    try
                    {
                        var section = _configuration.GetSection("StorageAccountSetting");                        
                        CloudStorageAccount storageAccount = CloudStorageAccount.Parse(section["ConnectionString"]);
                        cloudQueueClient = storageAccount.CreateCloudQueueClient();
                        cloudQueue = cloudQueueClient.GetQueueReference("message-send-notification");
                        cloudQueue.CreateIfNotExists();

                        var logData = new Model
                        {
                            UserId = model.UserId,
                            Message = model.Message,
                            ServiceResponse = json.status + string.Join(",", status == "success" ? json.messages : json.errors),
                            Number = model.Number
                        };

                        cloudQueuemessage = new CloudQueueMessage(JsonConvert.SerializeObject(logData));
                        cloudQueue.AddMessage(cloudQueuemessage);
                    }
                    catch (Exception ex)
                    {
                        if (status.ToLower() == "success")
                            return Ok(_responseFormatService.SetResponse(status, (string)json.balancejson, json.messages, false, string.Empty));                      
                        else
                            return Ok(_responseFormatService.SetResponse(status, string.Empty, json.errors, true,ex.Message));
                    }

                    if (status.ToLower() == "success")
                        return Ok(_responseFormatService.SetResponse(status, (string)json.balancejson, json.messages, false, string.Empty));
                    else
                        return Ok(_responseFormatService.SetResponse(status, string.Empty, json.errors, true,string.Empty));
                }
            }
            catch (Exception ex)
            {
                return Ok(_responseFormatService.SetResponse(status, string.Empty, ex.Message,false,string.Empty));
            }
        }
    }

    public class Model
    {
        [JsonProperty("number")]
        public string Number { get; set; }

        [JsonProperty("userId")]
        public Int64 UserId { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("serviceResponse")]
        public string ServiceResponse { get; set; }
    }
}
