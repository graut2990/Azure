﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiAppAsConnectorForLogicApp
{
    /// <summary>
    /// Reponse formatter class
    /// </summary>
    public class ResponseFormat : IResponseFormatService
    {
        /// <summary>
        /// Interface implemented method
        /// </summary>
        /// <param name="status"></param>
        /// <param name="balance"></param>
        /// <param name="result"></param>
        /// <param name="isQueueAdded"></param>
        /// <param name="queueExMsg"></param>
        /// <returns></returns>
        public dynamic SetResponse(string status, string balance, dynamic result,bool isQueueAdded,string queueExMsg)
        {
            return new { status = status, balance = balance, result = result, isQueueAdded = isQueueAdded, queueExMsg = queueExMsg };
        }
    }
}
