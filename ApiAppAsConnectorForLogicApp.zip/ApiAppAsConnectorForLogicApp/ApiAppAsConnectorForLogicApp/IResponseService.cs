﻿namespace ApiAppAsConnectorForLogicApp
{   
    /// <summary>
    /// Interface
    /// </summary>
    public interface IResponseFormatService
    {
        /// <summary>
        /// Response setting method
        /// </summary>
        /// <param name="status"></param>
        /// <param name="balance"></param>
        /// <param name="result"></param>
        /// <param name="isQueueAdded"></param>
        /// <param name="queueExMsg"></param>
        /// <returns></returns>
        dynamic SetResponse(string status, string balance, object result,bool isQueueAdded, string queueExMsg);
    }
}