﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Logger.Helper
{
    public class DbHelper
    {
        private static string connectionString;
        public DbHelper()
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder();
            sqlConnectionStringBuilder.DataSource = System.Environment.GetEnvironmentVariable("DataSource");
            sqlConnectionStringBuilder.UserID = System.Environment.GetEnvironmentVariable("UserID");
            sqlConnectionStringBuilder.Password = System.Environment.GetEnvironmentVariable("Password");
            sqlConnectionStringBuilder.InitialCatalog = System.Environment.GetEnvironmentVariable("InitialCatalog");

            connectionString = sqlConnectionStringBuilder.ConnectionString;
           
        }


        public static bool ExecuteNonQuery(CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {              
                connection.Open();

                switch ((int)commandType)
                {
                    case 4:
                        {
                            using (SqlCommand command = new SqlCommand(commandText, connection))
                            {
                                command.CommandType = commandType;
                                
                                command.ExecuteNonQuery();

                            }
                            break;
                        }

                }



               
             
            }


            return true;
        }


      
    }

}

