using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Logger.Model;
using Logger.Helper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Logger
{
    public static class GenerateLog
    {
        [FunctionName("LogMessageSentResponse")]
        public static void Run([QueueTrigger("message-send-notification", Connection = "AzureWebJobsStorage")]MessageServiceResponse messageServiceResponse, ILogger log)
        {
            DbHelper.ExecuteNonQuery(CommandType.StoredProcedure, "", new SqlParameter("@MobNumber", messageServiceResponse.Number),
                                                                   new SqlParameter("@Message", messageServiceResponse.Message),
                                                                   new SqlParameter("@ServiceResponse", messageServiceResponse.ServiceResponse),
                                                                   new SqlParameter("@UserId", messageServiceResponse.UserId));                
                   
            log.LogInformation($"C# Queue trigger function processed: {messageServiceResponse}");
        }
    }
}
