﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Model
{
    public class MessageServiceResponse
    {
        [JsonProperty("number")]
        public string Number { get; set; }

        [JsonProperty("userId")]
        public Int64 UserId { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("serviceResponse")]
        public string ServiceResponse { get; set; }
    }
    
}
